// Hashikko Player — パネルの見た目と操作。開いている間だけ1秒ごとにYouTubeの様子を聞きに行く。
const el = (id) => document.getElementById(id);

// ブラウザの言語に合わせた言葉（_locales/en・ja）
const t = (key, ...subs) => chrome.i18n.getMessage(key, subs) || key;
document.documentElement.lang = chrome.i18n.getUILanguage();
document.querySelectorAll('[data-i18n]').forEach((n) => { n.textContent = t(n.dataset.i18n); });
document.querySelectorAll('[data-i18n-title]').forEach((n) => { n.title = t(n.dataset.i18nTitle); });
document.querySelectorAll('[data-i18n-label]').forEach((n) => { n.setAttribute('aria-label', t(n.dataset.i18nLabel)); });

const ui = {
  art: el('art'), artBtn: el('artBtn'), title: el('title'), channel: el('channel'),
  progress: el('progress'), bar: el('bar'), cur: el('cur'), dur: el('dur'),
  prev: el('prev'), play: el('play'), next: el('next'),
  listTitle: el('listTitle'), count: el('count'), list: el('list'), empty: el('empty'),
};

let visible = true;   // 最初に読み込まれるのは「開いたとき」なので true から始める
let timer = null;
let state = null;
let listKey = '';
let selectedKey = '';
let artId = null;

const thumb = (id) => `https://i.ytimg.com/vi/${id}/mqdefault.jpg`;

function fmt(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  sec = Math.floor(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = String(sec % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${s}` : `${m}:${s}`;
}

async function call(type, extra = {}) {
  try {
    return (await chrome.runtime.sendMessage({ target: 'bg', type, ...extra })) || { ok: false };
  } catch {
    return { ok: false, reason: 'error' };
  }
}

// ---- 描画 ----
function renderEmpty(reason) {
  ui.title.textContent = t('notPlaying');
  ui.channel.textContent = '';
  ui.art.removeAttribute('src'); artId = null;
  ui.bar.style.width = '0%';
  ui.cur.textContent = ui.dur.textContent = '0:00';
  ui.play.classList.remove('playing');
  ui.list.replaceChildren(); listKey = ''; selectedKey = '';
  ui.count.textContent = '';
  ui.empty.hidden = false;
  ui.empty.textContent = reason === 'no-tab' ? t('emptyNoTab') : t('emptyNoConn');
}

function renderList(s) {
  const frag = document.createDocumentFragment();
  for (const item of s.items) {
    const li = document.createElement('li');
    const b = document.createElement('button');
    b.className = 'item' + (item.selected ? ' selected' : '');
    b.title = item.title;
    const img = document.createElement('img');
    img.loading = 'lazy';
    img.alt = '';
    img.src = thumb(item.id);
    const t = document.createElement('div');
    t.className = 'itext';
    const tt = document.createElement('div');
    tt.className = 'ititle';
    tt.textContent = item.title;
    const ts = document.createElement('div');
    ts.className = 'isub';
    ts.textContent = item.channel || '';
    t.append(tt, ts);
    b.append(img, t);
    b.addEventListener('click', () => {
      ui.list.querySelectorAll('.item.selected').forEach((x) => x.classList.remove('selected'));
      b.classList.add('selected');
      act('play', { mode: s.mode, index: item.index, id: item.id });
    });
    li.append(b);
    frag.append(li);
  }
  ui.list.replaceChildren(frag);
}

function scrollToSelected() {
  const sel = ui.list.querySelector('.item.selected');
  if (!sel) { ui.list.scrollTop = 0; return; }
  const li = sel.parentElement;
  ui.list.scrollTop = li.offsetTop - ui.list.clientHeight / 2 + li.offsetHeight / 2;
}

function render(s) {
  state = s;
  if (!s || !s.ok || !s.now) return renderEmpty(s && s.reason);
  ui.empty.hidden = true;

  const n = s.now;
  if (n.id !== artId) { ui.art.src = thumb(n.id); artId = n.id; }
  ui.title.textContent = n.title;
  ui.title.title = n.title;
  ui.channel.textContent = n.channel || '';
  ui.bar.style.width = (n.duration ? Math.min(100, (n.time / n.duration) * 100) : 0) + '%';
  ui.cur.textContent = fmt(n.time);
  ui.dur.textContent = n.duration ? fmt(n.duration) : 'LIVE';
  ui.play.classList.toggle('playing', !n.paused);
  ui.play.setAttribute('aria-label', n.paused ? t('play') : t('pause'));

  ui.listTitle.textContent = s.listTitle;
  const selIdx = s.items.findIndex((x) => x.selected);
  ui.count.textContent = !s.items.length ? ''
    : s.mode === 'playlist' ? `${selIdx >= 0 ? selIdx + 1 : '–'} / ${s.items.length}`
    : t('songCount', String(s.items.length));

  const key = s.mode + '|' + s.items.map((x) => x.id + (x.selected ? '*' : '')).join(',');
  if (key !== listKey) {
    const st = ui.list.scrollTop;
    renderList(s);
    const newSelected = s.mode + '|' + n.id;
    if (newSelected !== selectedKey) { scrollToSelected(); selectedKey = newSelected; }
    else ui.list.scrollTop = st; // 自分でスクロールした位置は保つ
    listKey = key;
  }
  if (!s.items.length) {
    ui.empty.hidden = false;
    ui.empty.textContent = t('loading');
  }
}

// ---- 更新ループ ----
async function refresh() { render(await call('getState')); }
function loop() {
  clearTimeout(timer);
  if (!visible) return;
  refresh().finally(() => { if (visible) timer = setTimeout(loop, 1000); });
}
async function act(type, extra) {
  await call(type, extra);
  setTimeout(refresh, 250);
  setTimeout(refresh, 900);
}

// ---- 操作 ----
ui.play.addEventListener('click', () => {
  ui.play.classList.toggle('playing'); // 押した瞬間に見た目を変える
  act('toggle');
});
ui.next.addEventListener('click', () => act('next'));
ui.prev.addEventListener('click', () => act('prev'));
ui.artBtn.addEventListener('click', () => call('focusTab'));
ui.progress.addEventListener('click', (e) => {
  const r = ui.progress.getBoundingClientRect();
  act('seek', { ratio: (e.clientX - r.left) / r.width });
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') window.parent.postMessage({ hashikko: true, type: 'close' }, '*');
  if (e.key === ' ') { e.preventDefault(); ui.play.click(); }
});

// 外側（edge.js）から「開いた / 閉じた」を受け取る
window.addEventListener('message', (e) => {
  if (!e.data || !e.data.hashikko || e.data.type !== 'visible') return;
  visible = !!e.data.value;
  if (visible) loop(); else clearTimeout(timer);
});

loop();
