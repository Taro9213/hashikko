// カレンダーの部品 — Google カレンダーの今日とあしたの予定を出す（読み取りだけ）。
// 予定は本体が Google から直接読む。Hashikko の窓口は通らない。鍵はこの PC の中だけ。
const api = window.hashikko;
const el = (id) => document.getElementById(id);
const views = ['intro', 'waiting', 'events', 'unavailable'];
const show = (v) => views.forEach((x) => { el(x).hidden = x !== v; });

let visible = false;
let events = [];
let lastLoad = 0;
let timer = null;

const REASONS = {
  denied: "You didn't allow access, so nothing was connected.",
  timeout: 'It took too long. Try again when you are ready.',
  google: "Google didn't finish connecting. Please try again.",
  offline: "Couldn't reach Google. Check your internet connection.",
};

function parse(s, allDay) {
  if (allDay) { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); }
  return new Date(s);
}
const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
const time = (d) => d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });

function fromNow(ms) {
  const min = Math.round(ms / 60000);
  if (min < 1) return 'now';
  if (min < 60) return `in ${min} min`;
  const h = Math.floor(min / 60), m = min % 60;
  return m ? `in ${h} h ${m} min` : `in ${h} h`;
}

function render() {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1);
  const items = events.map((e) => ({ ...e, s: parse(e.start, e.allDay), e: e.end ? parse(e.end, e.allDay) : null }));

  // いま・次の予定
  const current = items.find((x) => !x.allDay && x.s <= now && x.e && x.e > now);
  const next = items.find((x) => !x.allDay && x.s > now);
  const nx = el('next');
  nx.replaceChildren();
  if (current) {
    nx.className = 'next on';
    nx.append(Object.assign(document.createElement('small'), { textContent: `Now · until ${time(current.e)}` }), Object.assign(document.createElement('b'), { textContent: current.title || '(No title)' }));
  } else if (next) {
    nx.className = 'next';
    nx.append(Object.assign(document.createElement('small'), { textContent: `Next · ${sameDay(next.s, now) ? '' : 'tomorrow '}${fromNow(next.s - now)}` }), Object.assign(document.createElement('b'), { textContent: next.title || '(No title)' }));
  } else {
    nx.className = 'next none';
    nx.textContent = 'Nothing else scheduled today.';
  }

  const list = el('list');
  list.replaceChildren();
  for (const [label, day] of [['Today', today], ['Tomorrow', tomorrow]]) {
    const dayItems = items.filter((x) => (x.allDay ? sameDay(x.s, day) || (x.s < day && x.e && x.e > day) : sameDay(x.s, day)));
    const h = document.createElement('h2');
    h.textContent = `${label} · ${day.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}`;
    list.append(h);
    if (!dayItems.length) { list.append(Object.assign(document.createElement('p'), { className: 'empty', textContent: 'No events' })); continue; }
    for (const x of dayItems) {
      const b = document.createElement('button');
      b.className = 'ev' + (!x.allDay && x.e && x.e <= now ? ' past' : '') + (x === current ? ' current' : '');
      const t = document.createElement('span'); t.className = 'when';
      t.textContent = x.allDay ? 'All day' : time(x.s);
      const body = document.createElement('span'); body.className = 'what';
      const title = document.createElement('b'); title.textContent = x.title || '(No title)';
      body.append(title);
      if (x.location) body.append(Object.assign(document.createElement('small'), { textContent: x.location }));
      b.append(t, body);
      b.title = 'Open in Google Calendar';
      b.addEventListener('click', () => api.call('calendar.open', { id: x.id }));
      list.append(b);
    }
  }
}

async function load(force) {
  if (!force && Date.now() - lastLoad < 60 * 1000) { render(); return; }
  const r = await api.call('calendar.events', { days: 2 });
  if (r && r.ok) {
    events = r.events || [];
    lastLoad = Date.now();
    el('status').textContent = `Updated ${time(new Date())}`;
    show('events');
    render();
  } else if (r && r.reason === 'not-connected') {
    await refresh();
  } else {
    show('events');
    el('status').textContent = REASONS.offline;
    render();
  }
}

async function refresh() {
  const s = await api.call('calendar.status');
  if (!s || !s.ok) { show('unavailable'); return; }
  if (!s.configured) { show('unavailable'); return; }
  if (s.connecting) { show('waiting'); return; }
  if (!s.connected) { show('intro'); return; }
  show('events');
  await load(false);
}

el('connect').addEventListener('click', async () => {
  el('introNote').textContent = '';
  show('waiting');
  const r = await api.call('calendar.connect');
  if (r && r.ok) { await load(true); return; }
  show('intro');
  el('introNote').textContent = REASONS[r && r.reason] || REASONS.google;
});
el('openCal').addEventListener('click', () => api.call('calendar.open', {}));
let armed = false;
el('disconnect').addEventListener('click', async () => {
  if (!armed) { armed = true; el('disconnect').textContent = 'Disconnect? Click again'; setTimeout(() => { armed = false; el('disconnect').textContent = 'Disconnect'; }, 4000); return; }
  armed = false;
  el('disconnect').textContent = 'Disconnect';
  await api.call('calendar.disconnect');
  events = [];
  show('intro');
});

api.onVisible((v) => {
  visible = v;
  clearInterval(timer);
  if (!v) return;
  refresh();
  // 開いている間は、1分ごとに「次まであと何分」を更新し、5分ごとに予定を読み直す
  timer = setInterval(() => { if (Date.now() - lastLoad > 5 * 60 * 1000) load(true); else render(); }, 60 * 1000);
});
refresh();
