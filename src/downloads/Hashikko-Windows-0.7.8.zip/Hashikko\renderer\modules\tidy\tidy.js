// お片付けの部品 — 画面共有の前に、ボタン1つで画面を片付け、もう1回で元に戻す。
const api = window.hashikko;
const el = (id) => document.getElementById(id);
const ui = {
  go: el('go'), goMain: el('goMain'), goSub: el('goSub'), state: el('state'), opts: el('opts'),
  cover: el('cover'), windows: el('windows'), taskbar: el('taskbar'), colors: el('colors'), notif: el('notif'),
};

const COLORS = ['#1f2937', '#000000', '#ffffff', '#dbeafe', '#0f766e', '#f5efe6'];
const COLOR_NAMES = ['Charcoal', 'Black', 'White', 'Light blue', 'Teal', 'Beige'];
let options = { cover: true, windows: true, taskbar: false, color: COLORS[0], keepApps: [] };
let apps = [];                   // 今開いているアプリ（残すアプリを選ぶため）
let status = { active: false };
let message = '';                // ボタンの下に一時的に出す言葉
let timer = null;
let macText = false;             // Mac 版のアプリ本体のときは、Mac の言葉で出す

// Mac では「最小化」ではなく「隠す」、タスクバーではなく Dock
function useMacText() {
  if (macText) return;
  macText = true;
  el('winName').textContent = 'Hide other apps';
  el('winSub').textContent = "Keeps the app you're using and your meeting app";
  el('barName').textContent = 'Hide the Dock';
  el('barSub').textContent = 'It comes back when you point at it';
  el('note').textContent = 'Click "Restore" to bring your screen back exactly as it was. Your wallpaper and desktop icons are never changed, and the Dock setting is put back.';
  ui.notif.textContent = 'Open Focus settings (Do Not Disturb)';
}

// ---- 色の選択 ----
COLORS.forEach((c, i) => {
  const b = document.createElement('button');
  b.className = 'swatch c' + i;
  b.title = COLOR_NAMES[i];
  b.setAttribute('role', 'radio');
  b.addEventListener('click', () => { options.color = c; saveOptions(); renderOptions(); });
  ui.colors.append(b);
});

function renderOptions() {
  ui.cover.checked = !!options.cover;
  ui.windows.checked = !!options.windows;
  ui.taskbar.checked = !!options.taskbar;
  ui.colors.classList.toggle('off', !options.cover);
  [...ui.colors.children].forEach((b, i) => {
    const on = COLORS[i] === options.color;
    b.classList.toggle('selected', on);
    b.setAttribute('aria-checked', String(on));
  });
  if (!status.active) ui.go.disabled = !(options.cover || options.windows || options.taskbar);
  renderKeep();
}

// ---- 残すアプリ：画面共有しているアプリまで隠さないように ----
const keepKey = (a) => String(a).toLowerCase();
let picker = false;              // 本体が全画面の「残すアプリ」選びに対応しているか
function renderKeep() {
  const box = el('keep');
  box.classList.toggle('off', !options.windows);
  if (picker) {
    // 選ぶのは「Tidy up」を押したあとの全画面。ここでは何が起きるかだけを言う
    el('winSub').textContent = "After Tidy up, you pick which apps stay (like the one you're sharing)";
    box.replaceChildren();
    return;
  }
  const keep = new Set((options.keepApps || []).map(keepKey));
  const cap = document.createElement('p');
  cap.className = 'kcap';
  cap.textContent = 'Also keep visible (for example, the app you are sharing):';
  const rows = apps.map((a) => {
    const l = document.createElement('label');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = a.meeting || keep.has(keepKey(a.app));
    cb.disabled = !!a.meeting;
    cb.addEventListener('change', () => {
      const s = new Set((options.keepApps || []).map(keepKey));
      if (cb.checked) s.add(keepKey(a.app)); else s.delete(keepKey(a.app));
      options.keepApps = [...s];
      saveOptions();
    });
    const n = document.createElement('span'); n.className = 'kname'; n.textContent = a.name; n.title = a.name;
    l.append(cb, n);
    if (a.meeting) { const t = document.createElement('span'); t.className = 'ktag'; t.textContent = 'meeting app, always kept'; l.append(t); }
    return l;
  });
  if (!rows.length) { const e = document.createElement('p'); e.className = 'kempty'; e.textContent = 'No other apps are open right now.'; rows.push(e); }
  box.replaceChildren(cap, ...rows);
}

async function refreshApps() {
  const r = await api.call('tidy.apps');
  apps = (r && r.ok && r.apps) || [];
  renderKeep();
}

function saveOptions() { return api.call('storage.set', { key: 'options', value: options }); }

for (const key of ['cover', 'windows', 'taskbar']) {
  ui[key].addEventListener('change', () => { options[key] = ui[key].checked; saveOptions(); renderOptions(); });
}

// ---- 状態の表示 ----
function renderStatus() {
  const on = !!status.active;
  ui.go.classList.toggle('active', on);
  ui.goMain.textContent = on ? 'Restore' : 'Tidy up';
  ui.goSub.textContent = on ? 'Bring your screen back as it was' : 'One click before you share your screen';
  ui.opts.classList.toggle('locked', on);
  ui.state.classList.toggle('on', on);
  if (on) {
    const parts = [];
    if (status.cover) parts.push('desktop covered');
    if (status.windows) parts.push(status.windows + (macText ? (status.windows === 1 ? ' app' : ' apps') + ' hidden' : (status.windows === 1 ? ' window' : ' windows') + ' minimized'));
    if (status.taskbar) parts.push(macText ? 'Dock hidden' : 'taskbar hidden');
    const mins = status.minutes ? ' (' + status.minutes + ' min)' : '';
    ui.state.textContent = 'Tidied' + mins + ': ' + (parts.join(', ') || 'nothing to tidy');
    ui.go.disabled = false;
  } else {
    ui.state.textContent = message;
  }
  renderOptions();
}

async function refresh() {
  const r = await api.call('tidy.status');
  if (r && r.ok) { if (r.platform === 'mac') useMacText(); picker = !!r.picker; status = r; renderStatus(); }
}

// 全画面で「残すアプリ」を選んでもらう。やめたら null
async function pickKeep() {
  const saved = (options.keepApps || []).map(keepKey);
  const r = await api.call('tidy.pick', { keepApps: saved });
  if (!r || !r.ok) return null;
  const chosen = (r.keepApps || []).map(keepKey);
  // 次回のために覚える。「直前まで使っていたアプリ」は毎回自動で選ばれるので、外したときだけ覚え直す
  const cur = keepKey(r.current || '');
  options.keepApps = chosen.filter((k) => k !== cur || saved.includes(k));
  saveOptions();
  return chosen;
}

ui.go.addEventListener('click', async () => {
  ui.go.disabled = true;
  const wasActive = status.active;
  let opts = Object.assign({ keepCurrent: true }, options);
  if (!wasActive && picker && options.windows) {
    const chosen = await pickKeep();
    if (!chosen) { ui.go.disabled = false; return; }   // やめた
    opts = Object.assign({}, options, { keepCurrent: false, keepApps: chosen });
  }
  const r = wasActive
    ? await api.call('tidy.restore')
    : await api.call('tidy.apply', opts);
  if (r && r.ok) {
    if (r.platform === 'mac') useMacText();
    status = r;
    message = !wasActive ? ''
      : r.failed ? 'Restored (' + r.failed + (macText ? " app(s)" : " window(s)") + " couldn't be restored)"
      : 'Restored';
  } else {
    message = "Couldn't tidy up. Please try again.";
  }
  renderStatus();
});

ui.notif.addEventListener('click', () => api.call('settings.open', { page: 'notifications' }));

api.onVisible((v) => {
  clearInterval(timer);
  if (v) { refresh(); if (!status.active) refreshApps(); timer = setInterval(refresh, 30000); }
  else message = '';
});

(async () => {
  const r = await api.call('storage.get', { key: 'options' });
  if (r && r.value) options = Object.assign(options, r.value);
  renderOptions();
  refresh();
})();
