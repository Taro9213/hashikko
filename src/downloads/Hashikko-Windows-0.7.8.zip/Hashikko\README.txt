﻿Hashikko - preview version
==========================

Hashikko turns the edge of your screen into a home for small tools.
Thanks for trying it! It takes about 5 minutes.


HOW TO START (3 steps)

1. Right-click this zip file and choose "Extract All".
   (Just double-clicking the zip and opening the app from inside it will not work.)

2. In the extracted folder, double-click "HashikkoPlayer".

   If a blue "Windows protected your PC" screen appears,
   click "More info", then "Run anyway".
   (This appears because the app has not been officially published yet.
   It is not a sign that anything is wrong, and you only see it the first time.)

3. Move your pointer to the middle of the right edge of your screen.
   A small tab appears. Click it to open the panel.


WHAT TO TRY

- "Tidy" (the sparkle icon): click "Tidy up", pick the apps that should stay on screen
  (like the one you are sharing), then click "Restore" to bring everything back
- "Notes": type something
- Click "+" at the top right. You can:
    "Find a part"        add a ready-made tool (Timer, Calculator, and more)
    "Add a shared part"  add a part someone sent you (copy it first)
    "Make your own"      describe a tool and AI builds it
                         (you need a free Claude account). Hashikko shows you
                         each step on screen, and notices by itself when you
                         click "Copy" on the code Claude made.


SEND FEEDBACK

Click the gear icon in the panel -> "Email feedback in Gmail".
Gmail opens with a short form. Fill it in and send it.
(Use another email app? Click "Copy the form instead" and paste it into your email.)
Honest comments like "I got stuck here" or "I don't need this" help the most.


ABOUT THE MUSIC PART

"Music" (the note icon) shows whatever is playing on your PC:
Spotify, YouTube in Chrome or Edge, and more. Play, pause and skip work right there.

You don't need the "Chrome-extension-for-Music" folder for now. It is for showing
the whole YouTube playlist, and it will come to the Chrome Web Store soon.


IF SOMETHING GOES WRONG

- The tab on the right edge doesn't appear:
  Hashikko is probably not running (for example, after Windows restarted
  for an update). Double-click "HashikkoPlayer" in the extracted folder again.
  To keep it running after a restart: gear icon -> Startup -> "Open Hashikko when Windows starts".
- The tab appears but the panel is blank:
  right-click the Hashikko icon near the clock -> "Quit", then open it again.
- Music shows nothing: start playing something first, then open the panel.
- "Tidy" left windows hidden: open the panel and click "Restore".
  If Hashikko was closed while tidied, it puts things back the next time it starts.
- Still stuck? Gear icon -> "Email feedback in Gmail", and tell me what happened.


TO QUIT OR REMOVE

- Quit: right-click the Hashikko icon near the clock (bottom right) -> "Quit"
- Remove: delete the extracted folder.
- Your notes and settings are stored here. Delete this folder too to remove everything:
    %LOCALAPPDATA%\HashikkoPlayer
  (paste this into the File Explorer address bar and press Enter)
- If you turned on "Start with Windows", turn it off first (gear icon -> Startup).


PRIVACY

- Your notes and other data stay on this PC. Nothing is sent anywhere.
- Parts you add run in a sandbox that cannot connect to the internet.
- If it doesn't start on Windows 10, you may need the WebView2 Runtime:
  https://go.microsoft.com/fwlink/p/?LinkId=2124703
