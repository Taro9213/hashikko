// Hashikko 本体（シェル）— 上の部品バー、部品の切り替え、ストア、部品を作る画面、設定。
// 部品は1つずつ別の枠（iframe）で動き、頼みごとはすべてここを通ってアプリ本体（C#）に届く。
const host = window.chrome.webview;
const el = (id) => document.getElementById(id);
const lang = 'en';   // 画面は英語。部品の名前も英語を優先して出す
const text = (v) => (v && typeof v === 'object' ? (v[lang] || v.en || v.ja || '') : (v || ''));
const VIEWS = ['settings', 'hub', 'store', 'maker', 'share', 'report', 'channel'];   // 部品ではない、本体の画面

const pending = new Map();
let seq = 0;
let modules = [];                 // 入っている部品の説明書（manifest）の一覧
let catalog = [];                 // アプリに同梱の部品の一覧（ネットにつながらないときの予備）
let storeInfo = { enabled: false }; // みんなの部品のストア（GitHub）。本体が対応していなければ使わない
let remote = null;                // ストアから読んだ部品の一覧（読めていなければ null）
let storeOffline = false;
let blocked = [];                 // ストアで取り下げられたため、本体が止めている部品
const frames = new Map();         // 部品のid → { iframe, ready }
let active = null;                // 今開いている部品のid、または本体の画面の名前
let panelVisible = false;
let info = {};
let settings = { order: [], hidden: [], last: '', mode: 'NearHandle', welcomed: false };
const badges = new Set();
let mac = false;                  // Mac 版のアプリ本体のときは、Mac の言葉で出す
const pasteKeys = () => (mac ? '⌘V' : 'Ctrl + V');
const enterKey = () => (mac ? 'Return' : 'Enter');

// ---- アプリ本体とのやりとり ----
function call(type, extra, module = 'shell') {
  return new Promise((resolve) => {
    const id = ++seq;
    pending.set(id, resolve);
    host.postMessage({ kind: 'call', id, type, module, extra: extra || {} });
  });
}

host.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.kind === 'result') {
    const resolve = pending.get(m.id);
    if (resolve) { pending.delete(m.id); resolve(m.result); }
  } else if (m.kind === 'visible') {
    panelVisible = !!m.value;
    if (!panelVisible) closeMenu();
    notifyVisible();
    // AI に頼んで戻ってきたら、コピーされた部品を自分で探す（「コピーして戻る」に気づけなくても進めるように）
    if (panelVisible && active === 'maker' && step >= 2) loadCopied(true);
    else if (panelVisible) checkCopied();
  } else if (m.kind === 'event' && m.name === 'tidy') {
    setBadge('tidy', !!(m.data && m.data.active));
  } else if (m.kind === 'event' && m.name === 'store') {
    // 取り下げの一覧が変わった：部品を読み直し、止められた部品を閉じる
    reloadModules().then(() => {
      if (active && !VIEWS.includes(active) && !modules.some((x) => x.id === active)) activate(firstVisible(), false);
      else { renderTabs(); if (active === 'store') renderStore(); }
    });
  }
});

// ---- 部品とのやりとり ----
window.addEventListener('message', async (e) => {
  let id = null;
  for (const [mid, f] of frames) if (f.iframe.contentWindow === e.source) { id = mid; break; }
  if (!id) return;                                  // 知らない相手からの連絡は無視する
  const m = e.data || {};
  const f = frames.get(id);
  if (m.hk === 'call') {
    const result = await call(String(m.type), m.extra, id);   // 権限の確認はアプリ本体が行う
    if (f.iframe.contentWindow) f.iframe.contentWindow.postMessage({ hk: 'result', id: m.id, result }, '*');
    // 部品が何かをコピーしたら、何がコピーされたかを必ず見せる（見た目と違う文字を貼らせないように）
    if (String(m.type) === 'clipboard.write' && result && result.ok) {
      const man = modules.find((x) => x.id === id);
      notice(`${text(man && man.name) || 'A part'} copied: “${String((m.extra || {}).text || '').replace(/\s+/g, ' ').slice(0, 80)}”`);
    }
  } else if (m.hk === 'pong') {
    f.pong = Date.now();
  } else if (m.hk === 'ready') {
    f.ready = true;
    f.iframe.contentWindow.postMessage({ hk: 'visible', value: panelVisible && active === id }, '*');
  } else if (m.hk === 'close') {
    host.postMessage({ kind: 'close' });
  } else if (m.hk === 'focus') {
    const man = modules.find((x) => x.id === id);
    if (man && man.keyboard && active === id) call('shell.focus');
  }
});

// パネルの下に、短い知らせを出す
let noticeTimer = null;
function notice(msg, action) {
  const n = el('notice');
  n.textContent = msg;
  // 取り消しのボタンなど（{ label, run }）
  if (action) {
    const b = document.createElement('button');
    b.className = 'notice-act';
    b.textContent = action.label;
    b.addEventListener('click', () => { n.hidden = true; action.run(); });
    n.append(' ', b);
  }
  n.hidden = false;
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => { n.hidden = true; }, action ? 10000 : 6000);
}

// 部品をバーから外す・戻す。外したら、すぐ戻せるように知らせる（知らないうちに部品が消えたと思わせない）
function hidePart(id) {
  const m = modules.find((x) => x.id === id);
  settings.hidden = [...new Set([...(settings.hidden || []), id])];
  save();
  if (active === id) activate(firstVisible(), false); else renderTabs();
  if (active === 'settings') renderSettings();
  notice(`${m ? text(m.name) : 'The part'} is hidden from the bar. Its data is kept.`, { label: 'Undo', run: () => showPart(id) });
}
function showPart(id) {
  settings.hidden = (settings.hidden || []).filter((x) => x !== id);
  save(); renderTabs();
  if (active === 'settings') renderSettings();
  if (active === 'hub') renderHub();
}

// 見張り：あとから足した部品が、答えられないほど重くなっていたら止める（パソコンが重くならないように）
const PING_MS = 10000, STALL_MS = 25000;
let pingN = 0;
setInterval(() => {
  const now = Date.now();
  for (const [id, f] of [...frames]) {
    const man = modules.find((x) => x.id === id);
    if (!man || man.source !== 'added' || !f.iframe.contentWindow) continue;
    if (!f.pong) f.pong = f.started || now;
    if (now - f.pong > STALL_MS) {
      dropFrame(id);
      if (active === id) activate(firstVisible(), false);
      notice(`${text(man.name)} stopped responding, so Hashikko turned it off to keep your computer fast. Open it again to restart it.`);
      continue;
    }
    f.iframe.contentWindow.postMessage({ hk: 'ping', n: ++pingN }, '*');
  }
}, PING_MS);

function notifyVisible() {
  for (const [id, f] of frames) {
    if (f.ready && f.iframe.contentWindow) f.iframe.contentWindow.postMessage({ hk: 'visible', value: panelVisible && active === id }, '*');
  }
}

// 本体の画面で文字を打つとき（ストアの検索など）も、入力できるようにする
document.addEventListener('pointerdown', (e) => {
  if (e.target.closest && e.target.closest('textarea, input[type=text]')) call('shell.focus');
}, true);
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') host.postMessage({ kind: 'close' }); });

// ---- 部品バー ----
const isHidden = (id) => (settings.hidden || []).includes(id);

function shownModules() {
  const order = settings.order || [];
  const rank = (m) => { const i = order.indexOf(m.id); return i < 0 ? 1000 + (m.order || 500) : i; };
  return modules.slice().sort((a, b) => rank(a) - rank(b));
}

function icon(m) {
  const s = document.createElement('span');
  if (m.source === 'added' || !m.icon) {
    s.className = 'emoji';
    s.textContent = m.emoji || '🧩';
  } else {
    s.className = 'ico';
    const url = `url("${m.base}${m.icon}")`;
    s.style.webkitMaskImage = url;
    s.style.maskImage = url;
  }
  return s;
}

// ---- アイコンをドラッグして並べ替える（設定の ↑↓ と同じ settings.order に保存） ----
let dragMoved = false;
function startTabDrag(e, btn) {
  if (e.button !== 0) return;
  const bar = el('tabs');
  const startX = e.clientX;
  let dragging = false;
  // 動きは画面全体で追いかける（つかんだアイコンを並べ替えで動かすと、アイコンでの追跡が切れるため）
  const move = (ev) => {
    if (!dragging) {
      if (Math.abs(ev.clientX - startX) < 6) return;   // 少し動かすまでは、ふつうのクリック
      dragging = true;
      btn.classList.add('dragging');
    }
    ev.preventDefault();
    // カーソルの位置に合わせて、つかんだアイコンを入れかえる
    const others = [...bar.querySelectorAll('.tab')].filter((x) => x !== btn);
    const after = others.find((x) => { const r = x.getBoundingClientRect(); return ev.clientX < r.left + r.width / 2; });
    if (after) { if (btn.nextSibling !== after) bar.insertBefore(btn, after); } else if (bar.lastChild !== btn) bar.append(btn);
  };
  const up = () => {
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', up);
    window.removeEventListener('pointercancel', up);
    if (!dragging) return;
    btn.classList.remove('dragging');
    dragMoved = true;                                   // 直後の click で部品を開かない
    setTimeout(() => { dragMoved = false; }, 0);
    const shown = [...bar.querySelectorAll('.tab')].map((x) => x.dataset.id);
    const hidden = shownModules().map((m) => m.id).filter((id) => !shown.includes(id));
    settings.order = [...shown, ...hidden];
    save(); renderTabs();
    if (active === 'settings') renderSettings();
  };
  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', up);
  window.addEventListener('pointercancel', up);
}

function renderTabs() {
  const frag = document.createDocumentFragment();
  for (const m of shownModules()) {
    if (isHidden(m.id)) continue;
    const b = document.createElement('button');
    b.className = 'tab' + (active === m.id ? ' active' : '') + (badges.has(m.id) ? ' badge' : '');
    b.title = text(m.name);
    b.setAttribute('aria-label', text(m.name));
    b.dataset.id = m.id;
    b.append(icon(m));
    b.addEventListener('click', () => { if (dragMoved) { dragMoved = false; return; } activate(m.id); });
    b.addEventListener('pointerdown', (e) => startTabDrag(e, b));
    b.addEventListener('contextmenu', (e) => { e.preventDefault(); openMenu(m, b); });
    frag.append(b);
  }
  el('tabs').replaceChildren(frag);
  el('gear').classList.toggle('active', active === 'settings');
  el('add').classList.toggle('active', ['hub', 'store', 'maker', 'share', 'report'].includes(active));
  el('add').classList.toggle('badge', !!waitingPart);
}

// ---- 部品アイコンの右クリックメニュー ----
let menuFor = null;
let menuArmed = false;

function openMenu(m, tab) {
  menuFor = m;
  menuArmed = false;
  el('menuName').textContent = text(m.name);
  el('menuDel').hidden = m.source !== 'added';        // 最初から入っている部品は消せない（外すだけ）
  el('menuShare').hidden = !(storeInfo.canShare && m.source === 'added' && !m.store);   // 自分で作った部品だけ共有できる
  el('menuEdit').hidden = m.source !== 'added';        // 足した部品は、AI に頼んで直せる
  el('menuDel').textContent = 'Delete';
  el('menu').hidden = false;
  const r = tab.getBoundingClientRect();
  const w = el('menu').offsetWidth;
  el('menu').style.left = Math.max(6, Math.min(r.left, document.documentElement.clientWidth - w - 6)) + 'px';
  el('menu').style.top = (r.bottom + 4) + 'px';
}
function closeMenu() { el('menu').hidden = true; menuFor = null; }

el('menuEdit').addEventListener('click', () => {
  const id = menuFor.id;
  closeMenu();
  startEdit(id);
});
el('menuShare').addEventListener('click', () => {
  const id = menuFor.id;
  closeMenu();
  openShare(id);
});
el('menuHide').addEventListener('click', () => {
  const id = menuFor.id;
  closeMenu();
  hidePart(id);
});
el('menuDel').addEventListener('click', async () => {
  // データも一緒に消えるので、2回押して削除する
  if (!menuArmed) { menuArmed = true; el('menuDel').textContent = 'Click again to delete'; return; }
  const id = menuFor.id;
  closeMenu();
  await removePart(id);
  if (active === id) activate(firstVisible(), false); else renderTabs();
});
document.addEventListener('pointerdown', (e) => { if (!el('menu').hidden && !e.target.closest('#menu')) closeMenu(); }, true);
window.addEventListener('blur', closeMenu);   // 部品の画面を押したときも閉じる

function setBadge(id, on) {
  if (on) badges.add(id); else badges.delete(id);
  renderTabs();
}

function activate(id, remember = true) {
  const isView = VIEWS.includes(id);
  const m = modules.find((x) => x.id === id);
  if (!isView && !m) return;
  active = id;
  for (const v of VIEWS) el(v).hidden = v !== id;
  el('stage').hidden = isView;
  if (id === 'settings') renderSettings();
  if (id === 'store') { renderStore(); refreshRemote(); refreshSubmissions(); }
  if (id === 'hub') { renderHub(); checkCopied(); }
  if (!isView) {
    if (!frames.has(id)) {
      // 部品は、ほかの部品や本体に触れない「砂場」の中で動かす
      const iframe = document.createElement('iframe');
      iframe.setAttribute('sandbox', 'allow-scripts');
      iframe.title = text(m.name);
      iframe.src = m.base + (m.entry || 'index.html');
      frames.set(id, { iframe, ready: false, started: Date.now() });
      el('stage').append(iframe);
    }
    if (remember && settings.last !== id) { settings.last = id; save(); }
  }
  for (const [mid, f] of frames) f.iframe.classList.toggle('active', mid === id);
  renderTabs();
  notifyVisible();
}

function firstVisible() {
  const m = shownModules().find((x) => !isHidden(x.id));
  return m ? m.id : 'store';
}
const lastOrFirst = () => (modules.some((x) => x.id === settings.last) && !isHidden(settings.last) ? settings.last : firstVisible());

function save() { return call('storage.set', { key: 'settings', value: settings }); }

async function reloadModules() {
  const r = await call('shell.modules');
  modules = (r && r.modules) || [];
  blocked = (r && r.blocked) || [];
  for (const b of blocked) dropFrame(b.id);
}

function dropFrame(id) {
  const f = frames.get(id);
  if (f) { f.iframe.remove(); frames.delete(id); }
}

// ---- 部品を足す・外す ----
const REASONS = {
  'empty': 'Nothing was copied. Click "Copy" on the code the AI made, then try again.',
  'no-html': 'What you copied does not look like part code. Copy the whole code the AI made.',
  'no-manifest': 'The part has no manifest.',
  'bad-manifest': 'The part manifest is not written correctly.',
  'no-name': 'The part manifest has no name.',
  'too-big': 'The part is too large (400 KB max).',
};
const PERM_NAMES = { 'storage': 'saving its own data', 'clipboard.write': 'copying text' };

async function installPart(html) {
  const r = await call('part.install', { html });
  if (!r || !r.ok) return r;
  dropFrame(r.id);                               // 入れ直したときは、新しい中身で開き直す
  await reloadModules();
  settings.hidden = (settings.hidden || []).filter((x) => x !== r.id);
  save();
  return r;
}

async function removePart(id) {
  const r = await call('part.remove', { id });
  if (!r || !r.ok) return;
  dropFrame(id);
  await reloadModules();
  settings.order = (settings.order || []).filter((x) => x !== id);
  if (settings.last === id) settings.last = '';
  save();
}

// ---- ストア ----
const norm = (s) => String(s || '').toLowerCase().normalize('NFKC');
const STORE_REASONS = {
  'offline': "Couldn't reach the store. Check your connection and try again.",
  'own-part': 'You already have your own part with this name.',
  'changed': 'The store is updating. Try again in a minute.',
  'blocked': 'This part was removed from the store.',
  'not-in-store': 'This part is no longer in the store.',
};

// 並べる一覧：ストアが読めればストアの一覧、読めなければアプリに同梱の一覧
const shownCatalog = () => (remote ? remote.map((c) => Object.assign({ remote: true }, c)) : catalog);

let loadingRemote = false;
async function refreshRemote() {
  if (!storeInfo.enabled || loadingRemote) return;
  loadingRemote = true;
  const r = await call('store.catalog');
  loadingRemote = false;
  if (r && r.ok) { remote = r.parts || []; storeOffline = !!r.offline; }
  else storeOffline = true;
  // 使われた数・フォロワー・一時的に止めている部品（ストアのサービスから）
  if (storeInfo.canShare) { const s = await call('store.stats'); if (s && s.ok) storeStats = s; }
  if (active === 'store') renderStore();
}
let storeStats = { uses: {}, followers: {}, paused: [] };
const fmtCount = (n) => (n >= 1000000 ? (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M' : n >= 1000 ? (n / 1000).toFixed(1).replace(/\.0$/, '') + 'K' : String(n));
const isChannel = (id) => /^[0-9a-f]{12}$/.test(String(id || ''));
const following = (ch) => (settings.follows || []).includes(ch);
async function toggleFollow(ch, btn) {
  const on = !following(ch);
  btn.disabled = true;
  const r = await call('store.follow', { channel: ch, on });
  btn.disabled = false;
  if (!r || !r.ok) return;
  settings.follows = on ? [...new Set([...(settings.follows || []), ch])] : (settings.follows || []).filter((x) => x !== ch);
  storeStats.followers[ch] = r.followers;
  save();
  renderStore();
}

async function addFromStore(c) {
  if (c.remote) {
    const r = await call('store.install', { id: c.id });
    if (!r || !r.ok) return r;
    dropFrame(r.id);
    await reloadModules();
    settings.hidden = (settings.hidden || []).filter((x) => x !== r.id);
    save();
    return r;
  }
  const html = await (await fetch(`store/${c.id}.html`)).text();
  return installPart(html);
}

function renderBlocked() {
  const box = el('blockedNote');
  box.hidden = !blocked.length;
  if (!blocked.length) return;
  const head = document.createElement('b');
  head.textContent = blocked.length === 1 ? 'A part was turned off' : `${blocked.length} parts were turned off`;
  const rows = blocked.map((p) => {
    const row = document.createElement('div');
    row.className = 'row2';
    const t = document.createElement('span');
    t.textContent = `${text(p.name)}: ${p.reason}`;
    const del = document.createElement('button');
    del.className = 'secondary small';
    del.textContent = 'Delete';
    del.addEventListener('click', async () => { await removePart(p.id); renderStore(); });
    row.append(t, del);
    return row;
  });
  box.replaceChildren(head, ...rows);
}

let showMine = false;   // 「Made by you」を開いているか
function renderStore() {
  renderBlocked();
  const q = norm(el('q').value).trim();
  const byId = new Map(modules.map((m) => [m.id, m]));
  const list = shownCatalog();
  const hit = (c) => !q || norm([c.name, c.description, c.author, (c.keywords || []).join(' ')].join(' ')).includes(q);
  // 自分で作った部品（ストアの一覧にないもの）も、ここに並べる
  const inCatalog = new Set(list.map((c) => c.id));
  const mine = modules.filter((m) => m.source === 'added' && !m.store && !inCatalog.has(m.id))
    .map((m) => ({ id: m.id, name: text(m.name), description: text(m.description), emoji: m.emoji, mine: true }))
    .filter(hit);
  // 一時的に止めている部品は、新しく入れる人には出さない（入れている人には出す）。フォローしている人の部品と新しい部品を先に
  const NEW_MS = 14 * 86400000;
  const isNewPart = (c) => c.added && Date.now() - Date.parse(c.added) <= NEW_MS;
  const rank = (c) => (following(c.creator) ? 0 : 2) + (isNewPart(c) ? 0 : 1);
  const theirs = list.filter(hit).filter((c) => !(storeStats.paused || []).includes(c.id) || byId.has(c.id))
    .map((c, i) => [c, i]).sort((a, b) => rank(a[0]) - rank(b[0]) || a[1] - b[1]).map((x) => x[0]);
  // ストアの部品を先に。自分で作った部品は下にまとめて、ふだんはたたんでおく（探しているときは開く）
  const mineOpen = showMine || !!q;
  // 公式（Hashikko が作ったもの）と、みんなが作って共有したものを分けて出す。公式には、元から入っている部品（Notes など）も並べる
  const isOfficial = (c) => c.creator ? c.creator === 'hashikko' : !c.author || c.author === 'Hashikko';
  const builtins = modules.filter((m) => m.source === 'builtin').map((m) => ({ id: m.id, name: text(m.name), description: text(m.description), builtin: true })).filter(hit);
  const official = builtins.concat(theirs.filter(isOfficial));
  const creators = theirs.filter((c) => !isOfficial(c));
  const items = official.concat(creators, mineOpen ? mine : []);
  const frag = document.createDocumentFragment();
  const head = (label) => { const h = document.createElement('li'); h.className = 'cardhead'; h.textContent = label; frag.append(h); };
  const button = (label, cls, fn) => {
    const b = document.createElement('button');
    b.className = cls + ' small';
    b.textContent = label;
    b.addEventListener('click', fn);
    return b;
  };
  if (official.length) head('Made by Hashikko');
  const mineHead = () => {
    const h = document.createElement('li'); h.className = 'cardhead mineHead';
    const b = document.createElement('button'); b.className = 'minetoggle';
    b.textContent = `${mineOpen ? '▾' : '▸'} Made by you (${mine.length})`;
    b.addEventListener('click', () => { showMine = !showMine; renderStore(); });
    h.append(b); frag.append(h);
  };
  items.forEach((c, i) => {
    if (creators.length && i === official.length) head('From creators');
    if (mine.length && i === official.length + creators.length) mineHead();
    const li = document.createElement('li');
    li.className = 'card';
    let e = document.createElement('span'); e.className = 'emoji big'; e.textContent = c.emoji || '🧩';
    if (c.builtin && byId.get(c.id)) { e = icon(byId.get(c.id)); e.classList.add('big'); }
    const t = document.createElement('div'); t.className = 'ctext';
    const n = document.createElement('b'); n.textContent = c.name;
    if (c.remote && c.added && Date.now() - Date.parse(c.added) <= NEW_MS) { const nb = document.createElement('span'); nb.className = 'newbadge'; nb.textContent = 'New'; n.append(' ', nb); }
    const d = document.createElement('small'); d.textContent = c.description;
    t.append(n, d);
    // 自分の部品を審査に出していれば、その結果
    const sub = c.mine && latestSubmission(c.id);
    if (sub) {
      const st = document.createElement('span');
      st.className = 'subst ' + (sub.state || 'reviewing');
      st.textContent = SUB_STATES[sub.state] || SUB_STATES.reviewing;
      t.append(st);
      if (sub.message && sub.state !== 'reviewing') {
        // 審査した人からの一言。誰の言葉かが分かるように、見出しを付けて囲む
        const nt = document.createElement('span'); nt.className = 'subnote';
        const h = document.createElement('b'); h.textContent = 'Note from the reviewer';
        const q = document.createElement('span'); q.textContent = sub.message;
        nt.append(h, q);
        if (sub.state === 'needs-changes') {
          const fix = document.createElement('button'); fix.className = 'link small'; fix.textContent = 'Ask AI to fix it';
          fix.addEventListener('click', async () => { await startEdit(c.id); el('want').value = 'The store reviewer asked for this change: ' + sub.message; });
          nt.append(fix);
        }
        t.append(nt);
      }
    }
    if (c.remote) {
      const meta = document.createElement('div'); meta.className = 'cmeta';
      const by = document.createElement('span'); by.className = 'by'; by.textContent = 'by ' + (c.author || 'Unknown');
      const rep = document.createElement('button'); rep.className = 'report'; rep.textContent = 'Report';
      rep.title = 'Report a problem with this part';
      rep.hidden = !storeInfo.canShare;
      rep.addEventListener('click', () => openReport(c));
      if (!isOfficial(c)) meta.append(by);   // 公式の部品は「Made by Hashikko」の見出しの下にあるので、作者を書かない
      const uses = (storeStats.uses || {})[c.id];
      if (uses) { const u = document.createElement('span'); u.className = 'uses'; u.textContent = `· ${fmtCount(uses)} ${uses === 1 ? 'use' : 'uses'}`; meta.append(u); }
      meta.append(rep);
      t.append(meta);
      // 作った人をフォローする（ログインなし）。フォローした人の新しい部品が、いちばん上に出る
      if (isChannel(c.creator) && storeInfo.canShare) {
        const fl = document.createElement('button');
        fl.className = 'follow' + (following(c.creator) ? ' on' : '');
        const fc = (storeStats.followers || {})[c.creator] || 0;
        fl.textContent = (following(c.creator) ? '✓ Following ' : '+ Follow ') + (c.author || '') + (fc ? ` · ${fmtCount(fc)}` : '');
        fl.addEventListener('click', () => toggleFollow(c.creator, fl));
        t.append(fl);
      }
    }
    const btns = document.createElement('div'); btns.className = 'cbtns';
    const have = byId.get(c.id);
    if (have) {
      // ストアに新しい版があれば「Update」
      const old = have.store && have.store.sha256;
      if (c.remote && old && c.sha256 && old !== c.sha256) {
        const up = button('Update', 'primary', async () => {
          up.disabled = true; up.textContent = '…';
          const r = await addFromStore(c);
          if (r && r.ok) { activate(r.id); return; }
          up.disabled = false; up.textContent = 'Update';
          el('storeState').hidden = false; el('storeState').textContent = STORE_REASONS[r && r.reason] || "Couldn't update.";
        });
        btns.append(up);
      } else {
        // バーから外していた部品でも、ここから開けばバーに戻る
        btns.append(button(isHidden(c.id) ? 'Show' : 'Open', 'secondary', () => { if (isHidden(c.id)) showPart(c.id); activate(c.id); }));
      }
      if (c.mine) btns.append(button('Change', 'secondary', () => startEdit(c.id)));
      if (c.mine && storeInfo.canShare) btns.append(button('Share', 'secondary', () => openShare(c.id)));
      if (c.mine) {
        // 消す：1回目で「Delete?」、もう一度で、部品とそのデータを消す（設定の ✕ と同じ）
        const del = button('Delete', 'link danger-soft', async () => {
          if (!del.classList.contains('armed')) { del.classList.add('armed'); del.textContent = 'Really delete? Click again'; setTimeout(() => { if (del.isConnected) { del.classList.remove('armed'); del.textContent = 'Delete'; } }, 4000); return; }
          await removePart(c.id);
          renderTabs(); renderStore();
        });
        del.title = 'Delete this part and its data';
        t.append(del);
      }
    } else {
      const add = button('Add', 'primary', async () => {
        add.disabled = true; add.textContent = '…';
        let r = null;
        try { r = await addFromStore(c); } catch { /* 下で知らせる */ }
        if (r && r.ok) { activate(r.id); return; }
        add.disabled = false; add.textContent = "Couldn't add";
        if (r && STORE_REASONS[r.reason]) { el('storeState').hidden = false; el('storeState').textContent = STORE_REASONS[r.reason]; }
      });
      btns.append(add);
    }
    li.append(e, t, btns);
    frag.append(li);
  });
  if (mine.length && !mineOpen) mineHead();
  el('results').replaceChildren(frag);
  el('storeLink').hidden = !info.storeSite;
  el('storeState').hidden = !(storeInfo.enabled && storeOffline);
  if (storeInfo.enabled && storeOffline) el('storeState').textContent = remote ? 'Offline: showing the parts from last time.' : "Couldn't reach the store. Showing the parts that come with Hashikko.";
  el('makeText').textContent = !items.length
    ? `No part matches "${el('q').value.trim()}" yet. Ask AI and you can make it right here.`
    : "Can't find the tool you want? Ask AI to make it.";
}

// ---- ストアに共有する ----
let sharing = null;   // 共有しようとしている部品のid

const SUB_STATES = {
  reviewing: 'Sent · in review',
  listed: 'In the store',
  'needs-changes': 'Needs changes',
  declined: 'Not accepted',
  unknown: 'Sent',
};
let submissions = [];
const latestSubmission = (id) => submissions.filter((x) => x.part === id).sort((a, b) => (b.number || 0) - (a.number || 0))[0];
async function refreshSubmissions() {
  if (!storeInfo.canShare) return;
  const r = await call('store.submissions');
  if (r && r.ok) { submissions = r.items || []; if (active === 'store') renderStore(); }
}

const SHARE_REASONS = {
  'offline': "Couldn't reach Hashikko. Check your connection and try again.",
  'too-many': 'You sent a lot of parts in a short time. Please try again later.',
  'agree': 'Please check all three boxes.',
  'not-found': "This part couldn't be found.",
  'name-reserved': 'That name is reserved. Please use your own name or a nickname.',
  'name-required': 'Please type your name. It is shown on your parts in the store.',
  'signed-out': 'Please sign in with Google first (Settings → Your channel).',
  'no-channel': 'Please create your channel first (Settings → Your channel).',
  'terminated': 'Your channel was removed for breaking the store rules, so you can\'t share or report.',
  'restricted': 'You can\'t share for a while because of a strike on your channel. See Settings → Your channel.',
};
// ---- Google でログインと、自分のチャンネル（共有と報告のときだけ。使うだけならいらない） ----
let account = null;          // { signedIn, channel, status, appeals }
let afterChannel = null;     // チャンネルができたら、戻る先
const fmtDate = (t) => new Date(t).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
async function loadAccount() {
  if (!storeInfo.auth) { account = null; return null; }
  const r = await call('store.account');
  account = r && r.ok ? r : null;
  return account;
}
// 共有・報告の前に呼ぶ。ログインとチャンネルがそろっていれば true
async function needAccount(next, needChannel) {
  if (!storeInfo.auth) return true;
  await loadAccount();
  if (account && account.signedIn && (!needChannel || account.channel)) return true;
  afterChannel = next;
  openChannel();
  return false;
}
function openChannel() {
  activate('channel', false);
  renderChannel();
}
let suggested = '';
function renderChannel() {
  const a = account || {};
  el('cnOut').hidden = !!a.signedIn;
  el('cnMake').hidden = !a.signedIn || !!a.channel;
  el('cnMine').hidden = !a.signedIn || !a.channel;
  el('cnErr').hidden = true;
  el('cnWait').textContent = '';
  if (a.signedIn && !a.channel) {
    el('cnMakeTitle').textContent = 'Create your channel';
    el('cnSave').textContent = 'Create channel';
    if (!el('cnName').value) el('cnName').value = suggested;
  }
  if (a.channel) {
    const c = a.channel;
    el('cnAv').textContent = (c.name.trim()[0] || '?').toUpperCase();
    el('cnTitle').textContent = c.name;
    el('cnSub').textContent = `@${c.handle} · since ${fmtDate(c.created)}`;
    renderStanding(a.status || {}, a.appeals || []);
  }
}
const RULE_LINE = (x) => `${x.rule || 'Store rules'}${x.note ? ` — “${x.note}”` : ''}`;
function renderStanding(s, appeals) {
  const box = el('cnStatus');
  const rows = [];
  const appealed = new Set(appeals.map((x) => x.ref));
  const item = (cls, title, sub, ref) => {
    const d = document.createElement('div'); d.className = 'stand ' + cls;
    const b = document.createElement('b'); b.textContent = title;
    const p = document.createElement('small'); p.textContent = sub;
    d.append(b, p);
    if (ref && !appealed.has(ref)) {
      const ap = document.createElement('button'); ap.className = 'link small'; ap.textContent = 'This was a mistake? Appeal';
      ap.addEventListener('click', () => openAppeal(d, ref));
      d.append(ap);
    }
    rows.push(d);
  };
  if (s.terminated) item('bad', 'Your channel was removed', `${RULE_LINE(s.terminated)}. You can't share parts anymore.`, 'removed:' + s.terminated.id);
  else {
    if (s.restrictedUntil) item('warn', `You can't share until ${fmtDate(s.restrictedUntil)}`, 'Because of a strike on your channel.');
    (s.strikes || []).forEach((x, i) => item('warn', `Strike ${i + 1} of 3`, `${RULE_LINE(x)}. Ends ${fmtDate(x.at + 90 * 86400000)}.`, 'strike:' + x.id));
    (s.warnings || []).forEach((x) => item('info', 'Warning', `${RULE_LINE(x)}. Ends ${fmtDate(x.at + 90 * 86400000)}. Next time it's a strike.`, 'warning:' + x.id));
    if (!rows.length) item('good', 'All good', 'No warnings or strikes. Thanks for following the store rules.');
  }
  box.replaceChildren(...rows);
  el('cnAppeals').replaceChildren(...appeals.map((x) => {
    const d = document.createElement('div'); d.className = 'stand ' + (x.state === 'reversed' ? 'good' : x.state === 'upheld' ? 'info' : '');
    const b = document.createElement('b'); b.textContent = x.state === 'open' ? 'Appeal sent · in review' : x.state === 'reversed' ? 'Appeal accepted' : 'Appeal reviewed: decision stays';
    const p = document.createElement('small'); p.textContent = x.answer ? `Reviewer: “${x.answer}”` : `You wrote: “${x.text}”`;
    d.append(b, p);
    return d;
  }));
}
function openAppeal(box, ref) {
  const t = document.createElement('textarea'); t.className = 'field tall short'; t.placeholder = 'Tell the reviewers why you think this was a mistake.';
  const s = document.createElement('button'); s.className = 'primary small'; s.textContent = 'Send appeal';
  const msg = document.createElement('small');
  s.addEventListener('click', async () => {
    const r = await call('store.appeal', { ref, text: t.value.trim() });
    if (r && r.ok) { await loadAccount(); renderChannel(); return; }
    msg.textContent = r && r.reason === 'already-appealed' ? 'You already appealed this.' : 'Please write a little more, then try again.';
  });
  box.append(t, s, msg);
  t.addEventListener('pointerdown', () => call('shell.focus'));
  t.focus();
}
el('cnSignIn').addEventListener('click', async () => {
  const r = await call('store.signIn');
  if (!r || !r.ok) { el('cnWait').textContent = "Couldn't open the sign-in page. Please try again."; return; }
  el('cnWait').textContent = 'Finish signing in in your browser, then come back here.';
  const until = Date.now() + 5 * 60000;
  while (Date.now() < until && active === 'channel') {
    await new Promise((res) => setTimeout(res, 2000));
    const p = await call('store.signInPoll');
    if (p && p.ok && p.done) { suggested = p.suggestedName || ''; await loadAccount(); renderChannel(); return continueAfter(); }
    if (!p || !p.ok) break;
  }
  el('cnWait').textContent = "Didn't finish signing in. Click the button to try again.";
});
const CH_ERRORS = {
  'name-required': 'Please type a channel name.', 'name-reserved': 'That name is reserved. Please choose another.',
  'bad-handle': 'The handle can use 3–30 lowercase letters, numbers, dots or underscores.', 'handle-taken': 'That handle is taken. Try another.',
  'terminated': 'This channel was removed, so it can\'t be changed.', 'signed-out': 'Please sign in again.',
};
el('cnSave').addEventListener('click', async () => {
  const r = await call('store.setChannel', { name: el('cnName').value.trim(), handle: el('cnHandle').value.trim().toLowerCase() });
  if (r && r.ok) { await loadAccount(); renderChannel(); return continueAfter(); }
  el('cnErr').hidden = false;
  el('cnErr').textContent = CH_ERRORS[r && r.reason] || "Couldn't save. Please try again.";
});
['cnName', 'cnHandle'].forEach((id) => el(id).addEventListener('pointerdown', () => call('shell.focus')));
el('cnHandle').addEventListener('input', () => { el('cnHandle').value = el('cnHandle').value.toLowerCase().replace(/[^a-z0-9_.]/g, ''); });
el('cnEdit').addEventListener('click', () => {
  const c = account.channel;
  el('cnMine').hidden = true; el('cnMake').hidden = false;
  el('cnMakeTitle').textContent = 'Edit your channel'; el('cnSave').textContent = 'Save';
  el('cnName').value = c.name; el('cnHandle').value = c.handle;
});
el('cnSignOut').addEventListener('click', async () => { await call('store.signOut'); await loadAccount(); renderChannel(); });
el('cnBack').addEventListener('click', () => { afterChannel = null; activate(sharing ? 'store' : 'settings', false); });
function continueAfter() {
  if (!account || !account.signedIn) return;
  const next = afterChannel; afterChannel = null;
  if (next && (account.channel || next.kind === 'report')) next.go();
}

async function openShare(id) {
  const m = modules.find((x) => x.id === id);
  if (!m) return;
  sharing = id;
  if (!(await needAccount({ kind: 'share', go: () => openShare(id) }, true))) return;
  const auth = !!storeInfo.auth;
  el('shNameBox').hidden = auth;
  el('shAs').hidden = !auth;
  if (auth && account && account.channel) {
    const c = account.channel;
    el('shAs').replaceChildren();
    const b = document.createElement('span'); b.textContent = 'Sharing as ';
    const n = document.createElement('b'); n.textContent = `${c.name} (@${c.handle})`;
    const ch = document.createElement('button'); ch.className = 'link small'; ch.textContent = 'Your channel';
    ch.addEventListener('click', openChannel);
    el('shAs').append(b, n, ch);
  }
  el('shEmoji').textContent = m.emoji || '🧩';
  el('shName').textContent = text(m.name);
  el('shDesc').textContent = text(m.description);
  el('shAuthor').value = settings.author || '';
  document.querySelectorAll('.shAgree').forEach((c) => { c.checked = false; });
  el('shSend').disabled = true;
  el('shSend').hidden = false;
  el('shSend').textContent = 'Submit for review';
  el('shDone').hidden = true; el('shErrs').hidden = true; el('shFix').hidden = true; el('shNext').hidden = false;
  activate('share', false);
}
// 送れるのは、名前を入れて、3つにチェックしたときだけ（どの部品にも、作った人の名前が出る）
function updateShareButton() {
  const named = storeInfo.auth ? !!(account && account.channel) : el('shAuthor').value.trim().length >= 2;
  el('shSend').disabled = !named || ![...document.querySelectorAll('.shAgree')].every((x) => x.checked);
}
document.querySelectorAll('.shAgree').forEach((c) => c.addEventListener('change', updateShareButton));
el('shAuthor').addEventListener('input', updateShareButton);
el('shAuthor').addEventListener('pointerdown', () => call('shell.focus'));
el('shSend').addEventListener('click', async () => {
  const author = storeInfo.auth && account && account.channel ? account.channel.name : el('shAuthor').value.trim().slice(0, 40);
  if (author !== (settings.author || '')) { settings.author = author; save(); }
  el('shSend').disabled = true; el('shSend').textContent = 'Sending…';
  el('shErrs').hidden = true; el('shFix').hidden = true; el('shDone').hidden = true;
  const r = await call('store.submit', { id: sharing, author, agree: true });
  if (r && r.ok) {
    el('shSend').hidden = true;
    el('shNext').hidden = true;
    showDone(null, el('shDone'), true, "Sent for review! We'll check it, usually within a few days. You'll see the result under ＋ → Made by you.");
    submissions.push({ part: sharing, number: r.number, state: 'reviewing' });
    return;
  }
  el('shSend').disabled = false; el('shSend').textContent = 'Submit for review';
  if (r && r.errors && r.errors.length) {
    // 自動のチェックで止まった：理由を見せ、AI に直してもらう道を出す
    showDone(null, el('shDone'), false, "This part can't be shared yet. Here's why:");
    el('shErrs').replaceChildren(...r.errors.map((x) => { const li = document.createElement('li'); li.textContent = x; return li; }));
    el('shErrs').hidden = false;
    el('shFix').hidden = false;
    return;
  }
  showDone(null, el('shDone'), false, SHARE_REASONS[r && r.reason] || "Couldn't send it. Please try again.");
});
el('shFix').addEventListener('click', async () => {
  const problems = [...el('shErrs').children].map((li) => li.textContent).join(' ');
  await startEdit(sharing);
  el('want').value = 'Fix these problems so it can be shared in the store: ' + problems;
});

// ---- 部品を報告する ----
const REPORT_REASONS = [
  'Harmful, hateful or sexual content',
  'Tries to trick people (fake login, scam)',
  "Copies someone else's work, name or logo",
  'Does not work or does something unexpected',
  'Something else',
];
let reporting = null;
async function openReport(c) {
  // 報告にもログインが要る（誰が報告したかわかるように。いたずらの報告を減らす）
  if (!(await needAccount({ kind: 'report', go: () => openReport(c) }, false))) return;
  reporting = c.id;
  el('rpEmoji').textContent = c.emoji || '🧩';
  el('rpName').textContent = c.name;
  el('rpBy').textContent = 'by ' + (c.author || 'Unknown');
  el('rpReasons').replaceChildren(...REPORT_REASONS.map((t) => {
    const l = document.createElement('label'); l.className = 'row';
    const i = document.createElement('input'); i.type = 'radio'; i.name = 'rpReason'; i.value = t;
    i.addEventListener('change', () => { el('rpSend').disabled = false; });
    l.append(i, ' ' + t);
    return l;
  }));
  el('rpDetails').value = '';
  el('rpSend').disabled = true; el('rpSend').hidden = false;
  el('rpDone').hidden = true;
  activate('report', false);
}
el('rpDetails').addEventListener('pointerdown', () => call('shell.focus'));
el('rpSend').addEventListener('click', async () => {
  const reason = (document.querySelector('input[name=rpReason]:checked') || {}).value;
  if (!reason) return;
  el('rpSend').disabled = true;
  const r = await call('store.report', { id: reporting, reason, details: el('rpDetails').value.trim() });
  if (r && r.ok) { el('rpSend').hidden = true; showDone(null, el('rpDone'), true, 'Thanks. Your report was sent to the Hashikko team.'); return; }
  el('rpSend').disabled = false;
  showDone(null, el('rpDone'), false, SHARE_REASONS[r && r.reason] || "Couldn't send it. Please try again.");
});
el('rpBack').addEventListener('click', () => activate('store', false));

el('shBack').addEventListener('click', () => activate('store', false));

el('q').addEventListener('input', renderStore);
el('add').addEventListener('click', () => activate(['hub', 'store', 'maker', 'share', 'report'].includes(active) ? lastOrFirst() : 'hub', false));
el('stBack').addEventListener('click', () => activate('hub', false));
el('chFind').addEventListener('click', () => { activate('store', false); });
el('storeLink').addEventListener('click', () => call('shell.openUrl', { url: 'site:store' }));
el('chMake').addEventListener('click', () => { setEditing(null); showStep(1); activate('maker', false); });
el('makeBtn').addEventListener('click', () => {
  setEditing(null);
  const q = el('q').value.trim();
  if (q && !el('want').value.trim()) el('want').value = q;
  showStep(1);
  activate('maker', false);
});

// ---- 部品を作る（3ステップ） ----
let step = 1;
let pasted = '';       // 読み込んだコード
let lastProblem = '';  // うまくいかなかった理由（直してもらう依頼文に入れる）
let editing = null;    // 直している部品 { id, name, html }。新しく作るときは null
let lastPrompt = '';   // コピーした依頼文（これを部品と取り違えないため）
let lastSeen = '';     // 自分で見つけて読み込んだコード（同じものを何度も出さないため）

const promptText = () => window.makerPrompt(el('want').value.trim(), lastProblem, editing && editing.html);

// 足した部品を、AI に頼んで直す
function setEditing(e) {
  editing = e;
  el('mkTitle').textContent = e ? `What should change in ${e.name}?` : 'What tool do you want?';
  el('mkHint').textContent = e ? 'Say what is wrong or what you want to add. Short is fine.' : 'Describe it in your own words. Short is fine.';
  el('want').placeholder = e ? 'e.g. The buttons are too small. Also add a reset button.'
    : 'e.g. A timer that alternates 25 minutes of work and 5 minutes of rest, and changes color when time is up.';
  el('ideas').hidden = !!e;
}
async function startEdit(id) {
  const m = modules.find((x) => x.id === id);
  const r = await call('part.read', { id });
  if (!m || !r || !r.ok) return;
  setEditing({ id, name: text(m.name), html: r.html });
  el('want').value = '';
  lastProblem = '';
  showStep(1);
  activate('maker', false);
  el('want').focus();
}
const IDEAS = ['Pomodoro timer', 'Tip calculator', 'To-do list', 'Vocabulary notes', 'Dice roller', 'Water intake tracker'];

function showStep(n) {
  step = n;
  for (const i of [1, 2, 3]) {
    el('step' + i).hidden = i !== n;
    el('d' + i).className = i <= n ? 'on' : '';
  }
  el('stepNo').textContent = `${n} / 3`;
  if (n === 3) { el('found').hidden = true; el('mkError').hidden = true; el('fixBtn').hidden = true; }
  if (n === 2) el('askNote').textContent = '';
}
IDEAS.forEach((t) => {
  const b = document.createElement('button');
  b.className = 'chip'; b.textContent = t;
  b.addEventListener('click', () => { el('want').value = t; });
  el('ideas').append(b);
});
el('mkBack').addEventListener('click', () => { if (step > 1) showStep(step - 1); else { setEditing(null); activate('hub', false); } });
el('to2').addEventListener('click', () => {
  if (!el('want').value.trim()) { el('want').focus(); return; }
  lastProblem = '';
  showStep(2);
});
// 開くブラウザーは、使う人が選ぶ（勝手に既定のブラウザーで開かない）。前に選んだものを、いちばん上に大きく出す
let browsers = [];
function browserChoices() {
  const list = browsers.slice().sort((a, b) => (b.id === settings.browser) - (a.id === settings.browser));
  list.push({ id: '', name: 'your default browser' });
  return list;
}
function renderOpens() {
  el('opens').replaceChildren(...browserChoices().map((b, i) => {
    const btn = document.createElement('button');
    btn.className = (i === 0 ? 'primary' : 'secondary') + ' wide';
    btn.textContent = `Open in ${b.name}`;
    btn.addEventListener('click', () => copyPrompt(true, b));
    return btn;
  }));
}
async function copyPrompt(open, browser) {
  lastPrompt = promptText();
  const r = await call('shell.writeClipboard', { text: lastPrompt });
  if (!r || !r.ok) { el('askNote').textContent = "Couldn't copy. Please try again."; return; }
  if (open) {
    await call('shell.openUrl', browser.id ? { url: 'https://claude.ai/new', browser: browser.id } : { url: 'https://claude.ai/new' });
    if (settings.browser !== browser.id) { settings.browser = browser.id; save(); renderOpens(); }
  }
  el('askNote').textContent = open
    ? `Request copied. In Claude (opened in ${browser.name}), press ${pasteKeys()}, then ${enterKey()}.`
    : `Request copied. Paste it into Claude or another AI (${pasteKeys()}) and send it.`;
  startCoach(open, open ? browser.name : '');
}
// 画面全体に大きく「貼り付けて送る → コードの Copy を押す」を出し、コピーされた部品に自分で気づく（本体が対応していれば）
function startCoach(opened, browserName) {
  call('shell.coach', { opened, browser: browserName || '', edit: !!editing });
}
// 全画面の案内で見つけた部品を足す／直し方を出す
host.addEventListener('message', async (e) => {
  const m = e.data || {};
  if (m.kind !== 'event' || m.name !== 'coach' || !m.data) return;
  const html = m.data.html || '';
  lastSeen = html;   // パネルが開いたときに、同じものをもう一度見つけないように
  if (m.data.action === 'install') {
    const r = await installPart(html);
    if (r && r.ok) { el('want').value = ''; setEditing(null); showStep(1); activate(r.id); return; }
  }
  pasted = html;
  activate('maker', false);
  showStep(3);
  if (m.data.action === 'install' || m.data.action === 'load') loadCopied(false);
});
el('copyOnly').addEventListener('click', () => copyPrompt(false));
el('to3').addEventListener('click', () => showStep(3));

function makerError(reason) {
  lastProblem = REASONS[reason] || "This couldn't be loaded as a part.";
  el('mkError').textContent = lastProblem;
  el('mkError').hidden = false;
  el('found').hidden = true;
  el('fixBtn').hidden = !el('want').value.trim() || reason === 'empty';
}
// コピーされたコードを読み込む。auto のときは、部品らしいものが新しくコピーされているときだけ動く
async function loadCopied(auto) {
  const c = await call('shell.readClipboard');
  const t = (c && c.text) || '';
  if (auto) {
    const looksLikePart = t.includes('hashikko-manifest') && t.includes('</html>');
    const isOurRequest = t === lastPrompt || t.includes('You build "parts" (small tools)');
    if (!looksLikePart || isOurRequest || t === lastSeen) return;
    lastSeen = t;
    if (step !== 3) showStep(3);
  }
  pasted = t;
  const r = await call('part.inspect', { html: pasted });
  if (!r || !r.ok) { makerError(r && r.reason); return; }
  const man = r.manifest || {};
  el('mkError').hidden = true; el('fixBtn').hidden = true;
  el('fEmoji').textContent = man.emoji || '🧩';
  el('fName').textContent = text(man.name);
  el('fDesc').textContent = text(man.description);
  const perms = (man.permissions || []).map((p) => PERM_NAMES[p] || p);
  el('fPerm').textContent = (perms.length ? `This part can use: ${perms.join(', ')}.` : 'This part uses no special features.')
    + ' It cannot connect to the internet.'
    + (r.denied && r.denied.length ? ` Features that are not allowed (${r.denied.join(', ')}) were turned off.` : '')
    + (r.exists ? (editing && editing.id === r.id ? ' Your current version will be replaced.' : ' A part with the same name is installed; it will be replaced.') : '');
  el('foundTitle').textContent = auto ? 'Found the part you copied' : '';
  el('foundTitle').hidden = !auto;
  el('found').hidden = false;
  call('shell.coachStop');   // パネルで見つけたので、全画面の案内はもう要らない
}
el('paste').addEventListener('click', () => loadCopied(false));
el('install').addEventListener('click', async () => {
  const r = await installPart(pasted);
  if (!r || !r.ok) { makerError(r && r.reason); return; }
  el('want').value = '';
  setEditing(null);
  showStep(1);
  activate(r.id);
});
el('fixBtn').addEventListener('click', async () => {
  lastPrompt = promptText();
  await call('shell.writeClipboard', { text: lastPrompt });
  el('mkError').textContent = 'Fix request copied. Paste it into the same Claude chat, copy the new code, then click "Load copied code" again.';
  startCoach(false, '');
});

// ---- 設定 ----
function renderSettings() {
  const list = shownModules();
  const frag = document.createDocumentFragment();
  list.forEach((m, i) => {
    const li = document.createElement('li');
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = !isHidden(m.id);
    cb.title = 'Show';
    cb.addEventListener('change', () => { if (cb.checked) showPart(m.id); else hidePart(m.id); });
    const t = document.createElement('div');
    t.className = 'mtext';
    const n = document.createElement('div'); n.className = 'mname'; n.textContent = text(m.name);
    const d = document.createElement('div'); d.className = 'mdesc'; d.textContent = text(m.description);
    t.append(n, d);
    const mk = (label, title, fn, disabled) => {
      const b = document.createElement('button');
      b.className = 'move'; b.textContent = label; b.disabled = !!disabled; b.title = title;
      b.addEventListener('click', fn);
      return b;
    };
    const swap = (delta) => () => {
      const ids = list.map((x) => x.id);
      [ids[i], ids[i + delta]] = [ids[i + delta], ids[i]];
      settings.order = ids;
      save(); renderTabs(); renderSettings();
    };
    li.append(cb, icon(m), t, mk('↑', 'Move up', swap(-1), i === 0), mk('↓', 'Move down', swap(1), i === list.length - 1));
    if (m.source === 'added') {
      let armed = false;
      const del = mk('✕', 'Delete this part', async () => {
        if (!armed) { armed = true; del.textContent = 'Delete?'; del.classList.add('danger'); return; }   // 2回押して削除
        await removePart(m.id);
        renderTabs(); renderSettings();
      });
      li.append(del);
    }
    frag.append(li);
  });
  el('mods').replaceChildren(frag);
  document.querySelectorAll('input[name=mode]').forEach((r) => { r.checked = r.value === settings.mode; });
  document.querySelectorAll('#sizes button').forEach((b) => b.classList.toggle('on', b.dataset.size === settings.size));
  el('startup').checked = !!info.startup;
  el('startupRow').hidden = !!info.packaged;
  el('startupBtn').hidden = !info.packaged;
  el('fbStatus').hidden = true;
  el('ownerBox').hidden = !storeInfo.canShare;
  el('channelBox').hidden = !storeInfo.auth;
  if (storeInfo.auth) loadAccount().then((a) => {
    el('channelLine').textContent = a && a.channel ? `${a.channel.name} (@${a.channel.handle})` + (a.status && (a.status.strikes || []).length ? ` · ${a.status.strikes.length} strike(s)` : '')
      : a && a.signedIn ? 'Signed in. Create your channel to share parts.' : 'Sign in with Google to share parts and send reports.';
  });
  el('recDone').hidden = true;
  el('about').textContent = `Hashikko ${info.version || ''}\nYour notes and other data stay on this ${mac ? 'Mac' : 'PC'}.`;
  el('helpBox').hidden = !info.site;
  showUpdate();
  refreshInfo();   // 新しい版のお知らせは、あとから届くことがある
}

// ---- 新しい版のお知らせ（ホームページの version.json を本体が見ている） ----
function showUpdate() {
  const u = info.update;
  el('updateBox').hidden = !u;
  el('gear').classList.toggle('badge', !!u);
  if (!u) return;
  el('updTitle').textContent = `Hashikko ${u} is available`;
  el('updNotes').textContent = info.updateNotes || 'Download it from the Hashikko website. Your notes and parts stay as they are.';
}
async function refreshInfo() {
  const i = await call('shell.info');
  if (!i || !i.ok) return;
  const had = info.update;
  info = Object.assign(info, i);
  if (had !== info.update) showUpdate();
}
setInterval(refreshInfo, 30 * 60 * 1000);
setTimeout(refreshInfo, 20 * 1000);
el('updGet').addEventListener('click', () => call('shell.openUrl', { url: 'site:download' }));
el('helpOpen').addEventListener('click', () => call('shell.openUrl', { url: 'site:help' }));

document.querySelectorAll('input[name=mode]').forEach((r) => r.addEventListener('change', () => {
  if (!r.checked) return;
  settings.mode = r.value;
  save();
  call('shell.setMode', { mode: r.value });
}));
document.querySelectorAll('#sizes button').forEach((b) => b.addEventListener('click', () => {
  settings.size = b.dataset.size;
  save();
  call('shell.setSize', { size: settings.size });
  renderSettings();
}));
el('startup').addEventListener('change', async () => {
  const r = await call('shell.setStartup', { on: el('startup').checked });
  info.startup = !!(r && r.startup);
  el('startup').checked = info.startup;
});
el('startupBtn').addEventListener('click', () => call('shell.setStartup', {}));
el('gear').addEventListener('click', () => activate(active === 'settings' ? lastOrFirst() : 'settings', false));
// ---- 感想を送る：Gmail の「作成」画面を、あて先と用紙を入れた状態で開く（Google にログインしていなければ、Gmail がログインを求める） ----
const FEEDBACK_TO = 'hashikkotaro@gmail.com';
function feedbackForm() {
  const parts = modules.map((m) => text(m.name)).join(', ');
  return `Version: ${info.version || ''} (${mac ? 'Mac' : 'Windows'})\nParts installed: ${parts}\n\n1. When you first opened it, did you know what to do?\n\n2. The part you used most, and why:\n\n3. Anything confusing or annoying:\n\n4. A part you wish existed:\n\n5. Would you use it again tomorrow? (yes / no / not sure) Why?\n`;
}
async function copyFeedback(button) {
  const r = await call('shell.writeClipboard', { text: `[Hashikko feedback]\n${feedbackForm()}` });
  const ok = !!(r && r.ok);
  showDone(button, el('fbStatus'), ok,
    ok ? `Copied! Paste it (${pasteKeys()}) into an email to ${FEEDBACK_TO}.` : "Couldn't copy. Please try again.");
}
el('feedback').addEventListener('click', async () => {
  const r = await call('shell.openUrl', { url: 'feedback:gmail', body: feedbackForm() });
  if (r && r.ok) showDone(el('feedback'), el('fbStatus'), true, 'Gmail is opening in your browser. Fill in the form and press Send.');
  else await copyFeedback(el('feedback'));   // 本体が対応していない（古い版など）ときは、今までどおりコピー
});
el('feedbackCopy').addEventListener('click', () => copyFeedback(el('feedbackCopy')));

// ---- 人の部品を入れる（ストアのページの「Copy this part」、友だちから送られた部品など） ----
// パネルを開いたときにコピーされた部品に気づいたら、＋ に小さな点を付けて、＋ の中で待たせておく
let waitingPart = null;
async function checkCopied(force) {
  const r = await call('store.copiedPart', force ? { force: true } : {});
  if (r && r.ok && r.found) { waitingPart = r; renderTabs(); if (active === 'hub') renderHub(); return true; }
  if (r && r.reason === 'unknown') return null;   // 本体が対応していない
  return false;
}
function renderHub() {
  const hiddenMods = shownModules().filter((m) => isHidden(m.id));
  el('hiddenBox').hidden = !hiddenMods.length;
  el('hiddenChips').replaceChildren(...hiddenMods.map((m) => {
    const b = document.createElement('button');
    b.className = 'chip';
    b.append(icon(m), document.createTextNode(' ' + text(m.name)));
    b.addEventListener('click', () => { showPart(m.id); activate(m.id); });
    return b;
  }));
  const p = waitingPart;
  el('chShared').classList.toggle('has', !!p);
  el('cpCard').hidden = !p;
  el('cpPaste').hidden = !!p;
  el('cpHint').className = 'hint cphint';
  if (p) {
    el('cpEmoji').textContent = p.emoji || '🧩';
    el('cpName').textContent = text(p.name);
    el('cpSub').textContent = p.store ? `by ${p.store.author || 'Unknown'} · from the store` : p.exists ? 'Replaces the one you have now' : 'A part you copied';
    el('cpAdd').disabled = false;
    el('cpHint').textContent = 'Found the part you copied. Click Add to put it in your panel.';
  } else {
    el('cpHint').textContent = 'Copy the part first (on the store website, click "Copy this part"), then tap Paste.';
  }
}
el('cpPaste').addEventListener('click', async () => {
  const found = await checkCopied(true);
  if (found) return;
  el('cpHint').className = 'hint cphint bad';
  el('cpHint').textContent = found === null
    ? 'Update Hashikko to add shared parts.'
    : "There's no part in what you copied. Copy the whole part again, then tap Paste.";
});
el('cpAdd').addEventListener('click', async () => {
  el('cpAdd').disabled = true;
  const r = await call('store.addCopied');
  if (r && r.ok) {
    waitingPart = null;
    dropFrame(r.id);
    await reloadModules();
    settings.hidden = (settings.hidden || []).filter((x) => x !== r.id);
    save();
    activate(r.id);
    return;
  }
  waitingPart = null;
  renderHub(); renderTabs();
  el('cpHint').className = 'hint cphint bad';
  el('cpHint').textContent = STORE_REASONS[r && r.reason] || "Couldn't add it. Copy the part again, then tap Paste.";
});

// ---- 復元用のコード（共有した部品が自分のものだと示す鍵） ----
el('channelOpen').addEventListener('click', async () => { sharing = null; await loadAccount(); openChannel(); });
el('recCopy').addEventListener('click', async () => {
  const r = await call('store.recovery');
  const ok = !!(r && r.ok);
  showDone(el('recCopy'), el('recDone'), ok, ok
    ? `Copied! Paste it (${pasteKeys()}) somewhere safe, like a note or a password manager. Anyone with this code can update your parts, so don't share it.`
    : "Couldn't copy. Please try again.");
});
el('recUseBtn').addEventListener('click', () => { el('recUse').hidden = !el('recUse').hidden; });
el('recRestore').addEventListener('click', async () => {
  const r = await call('store.restore', { code: el('recCode').value });
  el('recCode').value = '';
  if (r && r.ok) { el('recUse').hidden = true; submissions = []; }
  showDone(null, el('recDone'), !!(r && r.ok), r && r.ok
    ? 'Done. The parts you shared from your other computer are yours here too.'
    : "That code doesn't look right. It starts with HK1- and has 8 groups of letters and numbers.");
});

// 「できました」をはっきり知らせる：押したボタンを少しのあいだ「✓ Copied」に変え、下に色つきの知らせを出す
function showDone(btn, box, ok, message) {
  box.textContent = message;
  box.classList.toggle('bad', !ok);
  box.hidden = false;
  box.style.animation = 'none'; void box.offsetWidth; box.style.animation = '';   // 2回目以降も目に入るよう、毎回動かす
  if (!ok || !btn) return;
  if (!btn.dataset.label) btn.dataset.label = btn.textContent;
  clearTimeout(btn._flash);
  btn.textContent = '✓ Copied';
  btn.classList.add('flash');
  btn._flash = setTimeout(() => { btn.textContent = btn.dataset.label; btn.classList.remove('flash'); }, 2500);
}

// ---- はじめての画面 ----
el('wStart').addEventListener('click', async () => {
  if (el('wStartup').checked && !info.packaged) {
    const r = await call('shell.setStartup', { on: true });
    info.startup = !!(r && r.startup);
  }
  settings.welcomed = true;
  save();
  el('welcome').hidden = true;
});

// ---- 起動 ----
(async () => {
  const [i, st] = await Promise.all([call('shell.info'), call('storage.get', { key: 'settings' })]);
  info = i || {};
  mac = info.platform === 'mac';
  if (mac) {
    el('pasteHow').textContent = `Press ${pasteKeys()}, then ${enterKey()}.`;
    el('startupText').textContent = 'Open Hashikko when you log in';
    el('startupHint').textContent = 'Hashikko starts by itself when you log in to your Mac, so the tab is always ready. Turn this off to start it yourself.';
    el('wStartupText').textContent = 'Start Hashikko when I log in';
  }
  await reloadModules();
  settings = Object.assign(settings, (st && st.value) || {});
  if (settings.mode && settings.mode !== info.mode) call('shell.setMode', { mode: settings.mode });
  // 大きさを一度も選んでいない人は L から（端のパネルは字が小さく感じやすいため）。選んだ人の設定はそのまま
  if (!settings.size) { settings.size = 'large'; save(); }
  if (settings.size !== info.size) call('shell.setSize', { size: settings.size });
  if (info.tidy && info.tidy.active) badges.add('tidy');
  showUpdate();
  try { catalog = await (await fetch('store/catalog.json')).json(); } catch { catalog = []; }
  const si = await call('store.info');
  storeInfo = si && si.ok ? si : { enabled: false };   // 本体がストアに対応していなければ、同梱の一覧だけ
  const br = await call('shell.browsers');
  browsers = (br && br.browsers) || [];
  renderOpens();

  // 初めてのときは、すぐ試せる「お片付け」から始める
  const ok = (id) => modules.some((x) => x.id === id) && !isHidden(id);
  activate(ok(settings.last) ? settings.last : ok('tidy') ? 'tidy' : firstVisible(), false);
  showStep(1);
  el('welcome').hidden = !!settings.welcomed;
  if (info.packaged) el('wStartup').closest('label').hidden = true;
  host.postMessage({ kind: 'ready' });
})();
