// 音楽の部品 — 見た目と操作。見えている間だけ1秒ごとに様子を聞きに行く。
// 相手は2つ：YouTube（Chrome 拡張機能経由。曲リストまで出せる）と、
// Windows で再生中のもの（Spotify のアプリなど。今の曲と操作だけ）。
const api = window.hashikko;
const el = (id) => document.getElementById(id);
const ui = {
  art: el('art'), artBtn: el('artBtn'), title: el('title'), channel: el('channel'),
  progress: el('progress'), bar: el('bar'), cur: el('cur'), dur: el('dur'),
  prev: el('prev'), play: el('play'), next: el('next'),
  listTitle: el('listTitle'), count: el('count'), list: el('list'), empty: el('empty'),
};

let visible = false;
let timer = null;
let listKey = '';
let selectedKey = '';
let artId = null;
let source = 'youtube';          // 今表示している相手：'youtube' か 'system'

const thumb = (id) => `https://i.ytimg.com/vi/${encodeURIComponent(id)}/mqdefault.jpg`;

function fmt(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  sec = Math.floor(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = String(sec % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${s}` : `${m}:${s}`;
}

async function call(type, extra = {}) {
  try {
    return (await api.call(type, extra)) || { ok: false };
  } catch {
    return { ok: false, reason: 'error' };
  }
}

const MESSAGES = {
  'no-extension': 'Play music in Spotify or another app and it will show up here.\n\nFor YouTube playlists, install the Hashikko Player extension for Chrome.',
  'no-tab': 'Play something on Spotify, YouTube or another app and it will show up here.',
  'timeout': 'The YouTube tab is not responding.\nTry reloading the YouTube tab.',
  // Mac：Spotify やミュージックの操作が許可されていない
  'not-allowed': 'Hashikko needs your OK to see what Spotify or Apple Music is playing.\n\nOpen System Settings → Privacy & Security → Automation, and turn on Spotify and Music under Hashikko.',
};
let sysApps = '';                // Mac では、読める相手が Spotify と Apple Music に限られる

// ---- 描画 ----
function renderEmpty(reason) {
  ui.title.textContent = 'Nothing playing';
  ui.channel.textContent = '';
  ui.art.removeAttribute('src'); artId = null;
  ui.bar.style.width = '0%';
  ui.cur.textContent = ui.dur.textContent = '0:00';
  ui.play.classList.remove('playing');
  ui.list.replaceChildren(); listKey = ''; selectedKey = '';
  ui.count.textContent = '';
  ui.list.hidden = false;
  ui.empty.classList.remove('hint');
  ui.empty.dataset.key = '';
  ui.empty.hidden = false;
  ui.empty.style.whiteSpace = 'pre-line';
  let msg = MESSAGES[reason] || 'Could not reach the YouTube tab. Try reloading it.';
  if (sysApps) msg = msg.replace('Spotify or another app', sysApps).replace('Spotify, YouTube or another app', sysApps.replace(' or ', ', ') + ' or YouTube');
  ui.empty.textContent = msg;
}

function renderList(s) {
  const frag = document.createDocumentFragment();
  for (const item of s.items) {
    const li = document.createElement('li');
    const b = document.createElement('button');
    b.className = 'item' + (item.selected ? ' selected' : '');
    b.title = item.title;
    const img = document.createElement('img');
    img.loading = 'lazy';
    img.alt = '';
    img.src = thumb(item.id);
    const t = document.createElement('div');
    t.className = 'itext';
    const tt = document.createElement('div');
    tt.className = 'ititle';
    tt.textContent = item.title;
    const ts = document.createElement('div');
    ts.className = 'isub';
    ts.textContent = item.channel || '';
    t.append(tt, ts);
    b.append(img, t);
    b.addEventListener('click', () => {
      ui.list.querySelectorAll('.item.selected').forEach((x) => x.classList.remove('selected'));
      b.classList.add('selected');
      act('play', { mode: s.mode, index: item.index, id: item.id });
    });
    li.append(b);
    frag.append(li);
  }
  ui.list.replaceChildren(frag);
}

function scrollToSelected() {
  const sel = ui.list.querySelector('.item.selected');
  if (!sel) { ui.list.scrollTop = 0; return; }
  const li = sel.parentElement;
  ui.list.scrollTop = li.offsetTop - ui.list.clientHeight / 2 + li.offsetHeight / 2;
}

function setButtons(canPrev, canNext) {
  ui.prev.disabled = !canPrev;
  ui.next.disabled = !canNext;
}

// ブラウザーで流れているもの（拡張機能がなくても、OS から今の曲だけは分かる）
const CHROME_LIKE = /^(Chrome|Edge|Brave|Arc|Opera|Vivaldi)$/;
const OTHER_BROWSER = /^(Safari|Firefox)$/;

// 曲リストの場所に出す案内。YouTube の曲リストは、Chrome 拡張機能があるときだけ出せる
function listHint(app, ytReason) {
  if (CHROME_LIKE.test(app) && ytReason === 'no-extension') {
    return { head: 'See the whole YouTube playlist here',
      body: 'Add the Hashikko Player extension to ' + app + ' and your YouTube mix or playlist will show up in this space.\nPlay, pause and skip already work without it.' };
  }
  if (OTHER_BROWSER.test(app)) {
    return { head: 'Playlists need Chrome',
      body: 'Play, pause and skip work in ' + app + '.\nTo see your YouTube mix or playlist here, play it in Chrome with the Hashikko Player extension.' };
  }
  // Spotify は、ほかのアプリに曲リストを渡す仕組みを、一般向けのアプリには開いていない（2026年の Spotify の開発者向けの決まり）
  if (/^Spotify$/i.test(app)) {
    return { head: 'Spotify keeps its playlists to itself',
      body: 'Spotify only lets other apps see the song that is playing now, so the playlist can\'t be shown here.\nPlay, pause, skip and seek work right here.' };
  }
  return { head: '', body: 'Play, pause and skip work here.\nSong lists are available for YouTube.' };
}

// OS で再生中のもの（Spotify、ブラウザーの YouTube など）を表示する。曲リストはないので、今の曲だけ
function renderSystem(m, ytReason) {
  source = 'system';
  ui.empty.hidden = false;
  const key = 'sys|' + m.title + '|' + m.artist;
  if (key !== artId) {
    if (m.thumb) ui.art.src = m.thumb; else ui.art.removeAttribute('src');
    artId = key;
  }
  ui.title.textContent = m.title || 'Unknown title';
  ui.title.title = m.title || '';
  ui.channel.textContent = [m.artist, m.app].filter(Boolean).join(' · ');
  ui.bar.style.width = (m.duration ? Math.min(100, (m.position / m.duration) * 100) : 0) + '%';
  ui.cur.textContent = fmt(m.position);
  ui.dur.textContent = m.duration ? fmt(m.duration) : '';
  ui.play.classList.toggle('playing', !!m.playing);
  ui.play.setAttribute('aria-label', m.playing ? 'Pause' : 'Play');
  ui.artBtn.title = '';
  ui.artBtn.classList.toggle('noart', !m.thumb);
  setButtons(m.canPrev, m.canNext);
  ui.listTitle.textContent = 'Now playing in ' + m.app;
  ui.count.textContent = '';
  if (listKey !== 'sys') { ui.list.replaceChildren(); listKey = 'sys'; selectedKey = ''; }
  // 空の曲リストは隠して、その場所に案内を出す
  ui.list.hidden = true;
  const h = listHint(m.app, ytReason);
  const hk = h.head + '|' + h.body;
  if (ui.empty.dataset.key !== hk) {
    ui.empty.dataset.key = hk;
    ui.empty.classList.toggle('hint', !!h.head);
    ui.empty.style.whiteSpace = 'pre-line';
    if (h.head) {
      const b = document.createElement('b');
      b.textContent = h.head;
      const p = document.createElement('span');
      p.textContent = h.body;
      ui.empty.replaceChildren(b, p);
    } else {
      ui.empty.textContent = h.body;
    }
  }
}

function render(s) {
  if (!s || !s.ok || !s.now) return renderEmpty(s && (s.reason || (s.ok && !s.now ? 'no-tab' : '')));
  source = 'youtube';
  ui.artBtn.classList.remove('noart');
  setButtons(true, true);
  ui.artBtn.title = 'Go to the YouTube tab';
  ui.list.hidden = false;
  ui.empty.classList.remove('hint');
  ui.empty.dataset.key = '';
  ui.empty.hidden = true;

  const n = s.now;
  if (n.id !== artId) { ui.art.src = thumb(n.id); artId = n.id; }
  ui.title.textContent = n.title;
  ui.title.title = n.title;
  ui.channel.textContent = n.channel || '';
  ui.bar.style.width = (n.duration ? Math.min(100, (n.time / n.duration) * 100) : 0) + '%';
  ui.cur.textContent = fmt(n.time);
  ui.dur.textContent = n.duration ? fmt(n.duration) : 'LIVE';
  ui.play.classList.toggle('playing', !n.paused);
  ui.play.setAttribute('aria-label', n.paused ? 'Play' : 'Pause');

  ui.listTitle.textContent = s.listTitle;
  const selIdx = s.items.findIndex((x) => x.selected);
  ui.count.textContent = !s.items.length ? ''
    : s.mode === 'playlist' ? `${selIdx >= 0 ? selIdx + 1 : '–'} / ${s.items.length}`
    : `${s.items.length} songs`;

  const key = s.mode + '|' + s.items.map((x) => x.id + (x.selected ? '*' : '')).join(',');
  if (key !== listKey) {
    const st = ui.list.scrollTop;
    renderList(s);
    const newSelected = s.mode + '|' + n.id;
    if (newSelected !== selectedKey) { scrollToSelected(); selectedKey = newSelected; }
    else ui.list.scrollTop = st;
    listKey = key;
  }
  if (!s.items.length) {
    ui.empty.hidden = false;
    ui.empty.textContent = 'Loading the song list…';
  }
}

// ---- 更新ループ ----
// どちらを出すか：YouTube が流れていれば YouTube。そうでなければ、Windows で流れているもの（Spotify など）。
// どちらも止まっていれば、YouTube のタブがあれば YouTube、なければ Windows のもの。
async function refresh() {
  const yt = await call('getState');
  const ytHere = yt && yt.ok && yt.now;
  if (ytHere && !yt.now.paused) return render(yt);
  const sys = await call('media.state');
  if (sys && sys.apps) sysApps = sys.apps;
  if (!ytHere && sys && sys.reason === 'not-allowed') return renderEmpty('not-allowed');
  const sysHere = sys && sys.ok && (sys.title || sys.artist);
  // YouTube のタブが一時停止中で、Windows 側の相手が同じブラウザーなら、曲リストのある YouTube を出す
  const sameBrowser = sysHere && ytHere && /Chrome|Edge/.test(sys.app) && !sys.playing;
  if (sysHere && (sys.playing || !ytHere) && !sameBrowser) return renderSystem(sys, yt && yt.reason);
  render(yt);
}
function loop() {
  clearTimeout(timer);
  if (!visible) return;
  refresh().finally(() => { if (visible) timer = setTimeout(loop, 1000); });
}
async function act(type, extra) {
  // Windows で再生中のもの（Spotify など）を出しているときは、そちらを操作する
  if (source === 'system' && ['toggle', 'next', 'prev', 'seek'].includes(type)) type = 'media.' + type;
  await call(type, extra);
  setTimeout(refresh, 250);
  setTimeout(refresh, 900);
}

// ---- 操作 ----
ui.play.addEventListener('click', () => {
  ui.play.classList.toggle('playing');
  act('toggle');
});
ui.next.addEventListener('click', () => act('next'));
ui.prev.addEventListener('click', () => act('prev'));
ui.artBtn.addEventListener('click', () => { if (source === 'youtube') call('focusTab'); });
ui.progress.addEventListener('click', (e) => {
  const r = ui.progress.getBoundingClientRect();
  act('seek', { ratio: (e.clientX - r.left) / r.width });
});

document.addEventListener('keydown', (e) => {
  if (e.key === ' ') { e.preventDefault(); ui.play.click(); }
});

// アプリ本体から「開いた / 閉じた」を受け取る
api.onVisible((v) => {
  visible = v;
  document.body.classList.toggle('open', v);
  if (v) loop(); else clearTimeout(timer);
});
