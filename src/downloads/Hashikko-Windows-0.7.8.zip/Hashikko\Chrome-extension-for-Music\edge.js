// Hashikko Player — どのページにも置かれる見張り役。
// カーソルを画面の右端に近づけると小さな「つまみ」が出て、それをクリックするとパネルが開く。
(() => {
  const ROOT_ID = 'hashikko-player-root';
  document.getElementById(ROOT_ID)?.remove(); // 拡張を更新したときの古いものを片付ける

  const PANEL_URL = chrome.runtime.getURL('panel.html');
  const PANEL_ORIGIN = new URL(PANEL_URL).origin;
  const NEAR_PX = 56;        // 右端からこの距離に近づいたら、つまみを出す
  const NEAR_SPAN_PX = 130;  // つまみの上下この範囲で近づいたら出す
  const LINGER_MS = 700;     // 離れてもこれだけはつまみを残す
  const HIDE_MS = 400;       // パネルから離れてこれだけ経ったら閉じる
  const APP_CHECK_MS = 5000; // Windowsアプリが動いているかを聞き直す間隔

  const host = document.createElement('div');
  host.id = ROOT_ID;
  const shadow = host.attachShadow({ mode: 'open' });
  // innerHTML はYouTubeなど一部のサイトで禁止されているので、要素を直接作る
  const style = document.createElement('style');
  style.textContent = `
      :host { all: initial; }
      .frame {
        position: fixed; right: 10px; top: 50%;
        width: 340px; height: min(620px, 88vh);
        border: 0; border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0,0,0,.35), 0 2px 8px rgba(0,0,0,.2);
        z-index: 2147483647;
        transform: translate(calc(100% + 30px), -50%);
        opacity: 0; pointer-events: none;
        transition: transform .24s cubic-bezier(.2,.8,.2,1), opacity .18s ease;
      }
      .frame.open { transform: translate(0, -50%); opacity: 1; pointer-events: auto; }

      /* 右端のつまみ。ふだんは画面の外に隠れていて、近づくと18pxだけ顔を出す */
      .tab {
        position: fixed; right: 0; top: 50%;
        width: 26px; height: 64px; box-sizing: border-box;
        border-radius: 10px 0 0 10px;
        background: rgba(30, 30, 36, .9);
        border: 1px solid rgba(255, 255, 255, .2); border-right: 0;
        box-shadow: 0 2px 10px rgba(0, 0, 0, .25);
        z-index: 2147483646; cursor: pointer;
        transform: translate(100%, -50%);
        transition: transform .16s cubic-bezier(.2,.8,.2,1), background .12s;
      }
      .tab.show { transform: translate(8px, -50%); }
      .tab.show:hover { transform: translate(0, -50%); background: rgba(20, 184, 166, .96); border-color: transparent; }
      .tab::after {
        content: ""; position: absolute; left: 2px; top: 50%;
        width: 8px; height: 8px; border: 2px solid #fff; border-radius: 50%;
        transform: translateY(-50%); transition: left .16s;
      }
      .tab.show:hover::after { left: 6px; }`;
  shadow.appendChild(style);

  const tab = document.createElement('div');
  tab.className = 'tab';
  tab.setAttribute('role', 'button');
  try { tab.title = chrome.i18n.getMessage('extName') || 'Hashikko Player'; } catch {}
  shadow.appendChild(tab);
  document.documentElement.appendChild(host);

  let frame = null;
  let open = false;
  let hideTimer = null;
  let tabTimer = null;
  let frameReady = false; // パネルの読み込みが終わるまでは送らない（読み込み中は宛先が違うのでエラーになる）

  // ---------- Windowsアプリが動いているか（動いていればアプリ側のつまみに任せる） ----------
  let appConnected = false;
  let appCheckedAt = 0;
  function checkApp() {
    const now = Date.now();
    if (now - appCheckedAt < APP_CHECK_MS) return;
    appCheckedAt = now;
    chrome.runtime.sendMessage({ target: 'bg', type: 'appConnected' })
      .then((r) => { appConnected = !!(r && r.connected); if (appConnected) hideTab(); })
      .catch(() => { appConnected = false; });
  }

  checkApp(); // 最初に一度聞いておく（つまみが2つ出ないように）

  // ---------- パネル ----------
  function post(msg) {
    if (!frameReady) return;
    frame?.contentWindow?.postMessage({ hashikko: true, ...msg }, PANEL_ORIGIN);
  }

  function ensureFrame() {
    if (frame) return;
    frame = document.createElement('iframe');
    frame.className = 'frame';
    frame.addEventListener('load', () => {
      frameReady = true;
      post({ type: 'visible', value: open }); // 読み込み中に開閉していた分を伝える
    });
    frame.src = PANEL_URL;
    frame.addEventListener('mouseenter', () => { clearTimeout(hideTimer); hideTimer = null; });
    frame.addEventListener('mouseleave', () => { clearTimeout(hideTimer); hideTimer = setTimeout(hide, HIDE_MS); });
    shadow.appendChild(frame);
  }

  function show() {
    clearTimeout(hideTimer);
    hideTimer = null;
    if (open) return;
    ensureFrame();
    open = true;
    hideTab();
    frame.getBoundingClientRect(); // 一度位置を確定させてから動かす（スライドのアニメーション用）
    frame.classList.add('open');
    post({ type: 'visible', value: true });
  }

  function hide() {
    clearTimeout(hideTimer);
    hideTimer = null;
    if (!open) return;
    open = false;
    frame.classList.remove('open');
    post({ type: 'visible', value: false });
  }

  // ---------- つまみ ----------
  function showTab() {
    clearTimeout(tabTimer);
    tab.classList.add('show');
  }
  function hideTab() {
    clearTimeout(tabTimer);
    tab.classList.remove('show');
  }
  function hideTabLater() {
    if (!tab.classList.contains('show') || tabTimer) return;
    tabTimer = setTimeout(() => { tabTimer = null; if (!tab.matches(':hover')) hideTab(); }, LINGER_MS);
  }

  tab.addEventListener('click', (e) => {
    e.stopPropagation();
    show();
  });
  tab.addEventListener('mouseleave', () => hideTabLater());

  // ---------- カーソルの見張り（スクロールバーの上でも位置は届くので、window全体で見る） ----------
  window.addEventListener('mousemove', (e) => {
    if (open) {
      // パネルの外（ページの上）を動いている。パネルの中ではページに位置が届かない
      if (!hideTimer) hideTimer = setTimeout(() => { hideTimer = null; hide(); }, HIDE_MS + 250);
      return;
    }
    const near =
      !document.fullscreenElement &&                       // 全画面の動画などの邪魔をしない
      e.clientX >= window.innerWidth - NEAR_PX &&
      Math.abs(e.clientY - window.innerHeight / 2) <= NEAR_SPAN_PX;
    if (near) {
      checkApp();
      if (!appConnected) showTab();
    } else {
      hideTabLater();
    }
  }, { capture: true, passive: true });

  // ページを離れたら、つまみを片付ける
  document.addEventListener('mouseleave', () => hideTabLater());

  // パネルの外をクリックしたら、すぐ閉じる
  window.addEventListener('mousedown', (e) => {
    if (open && !e.composedPath().includes(host)) hide();
  }, true);

  // パネル内で Esc を押したとき
  window.addEventListener('message', (e) => {
    if (frame && e.source === frame.contentWindow && e.data?.hashikko && e.data.type === 'close') hide();
  });

  // Alt+Shift+Y
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.target === 'edge' && msg.type === 'toggle') open ? hide() : show();
  });
})();
