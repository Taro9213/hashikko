// Hashikko Player — YouTubeタブの中で動く受け手。今の曲と曲リストを読み取り、操作を実行する。
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const text = (el) => (el ? el.textContent : '').replace(/\s+/g, ' ').trim();
  const firstText = (root, selectors) => {
    for (const s of selectors) {
      const t = text(root.querySelector(s));
      if (t) return t;
    }
    return '';
  };

  function videoIdOf(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.origin);
      return u.pathname === '/watch' ? u.searchParams.get('v') : null;
    } catch {
      return null;
    }
  }

  const video = () => $('#movie_player video') || $('video');
  const params = () => new URLSearchParams(location.search);

  // ---- 今の曲 ----
  function nowPlaying() {
    const id = params().get('v');
    if (location.pathname !== '/watch' || !id) return null;
    const md = navigator.mediaSession && navigator.mediaSession.metadata;
    const v = video();
    return {
      id,
      title:
        text($('ytd-watch-metadata h1')) ||
        (md && md.title) ||
        document.title.replace(/^\(\d+\)\s*/, '').replace(/ - YouTube$/, ''),
      channel:
        text($('ytd-watch-metadata ytd-channel-name a')) ||
        text($('ytd-watch-metadata #channel-name a')) ||
        (md && md.artist) || '',
      paused: v ? v.paused : true,
      time: v ? v.currentTime : 0,
      duration: v && isFinite(v.duration) ? v.duration : 0,
    };
  }

  // ---- プレイリスト ----
  function playlistPanel() {
    const panels = $$('ytd-playlist-panel-renderer')
      .filter((p) => p.querySelector('ytd-playlist-panel-video-renderer'));
    return panels.find((p) => p.offsetParent !== null) || panels[0] || null;
  }
  const playlistRows = (p) => $$('ytd-playlist-panel-video-renderer', p);
  const rowAnchor = (r) => r.querySelector('a#wc-endpoint') || r.querySelector('a[href*="/watch"]');
  const rowId = (r) => { const a = rowAnchor(r); return a && videoIdOf(a.getAttribute('href')); };

  function playlistItems(p) {
    const items = [];
    playlistRows(p).forEach((r, index) => {
      const id = rowId(r);
      if (!id) return;
      items.push({
        index,
        id,
        title: text(r.querySelector('#video-title')),
        channel: text(r.querySelector('#byline')),
        selected: r.hasAttribute('selected'),
      });
    });
    return items;
  }

  function playlistTitle(p) {
    return firstText(p, ['#header-description .title', '.header .title', 'h3 .title', '.title']);
  }

  // ---- おすすめ（次の候補） ----
  const relatedRoot = () => $('#related') || $('ytd-watch-next-secondary-results-renderer') || document;
  const CARD = [
    'ytd-compact-video-renderer',
    'ytd-compact-radio-renderer',
    'yt-lockup-view-model',
  ].join(',');

  function relatedItems(excludeId) {
    const seen = new Set();
    const items = [];
    for (const c of $$(CARD, relatedRoot())) {
      if (c.closest('ytd-ad-slot-renderer')) continue;
      const a = c.querySelector('a[href*="/watch?v="]');
      if (!a) continue;
      const href = a.getAttribute('href');
      const id = videoIdOf(href);
      if (!id || id === excludeId || seen.has(id)) continue;
      const title =
        firstText(c, [
          '#video-title',
          '.ytLockupMetadataViewModelTitle',
          '.yt-lockup-metadata-view-model__title',
          '.yt-lockup-metadata-view-model-wiz__title',
          'h3',
        ]) || a.getAttribute('title') || '';
      if (!title) continue;
      const channel = firstText(c, [
        'ytd-channel-name #text',
        '.ytContentMetadataViewModelMetadataText',
        '.yt-content-metadata-view-model__metadata-text',
        '.yt-content-metadata-view-model-wiz__metadata-text',
      ]);
      seen.add(id);
      items.push({ index: items.length, id, title, channel, mix: /[?&]list=/.test(href) });
    }
    return items;
  }

  // ---- 全体の状態 ----
  // ブラウザの言語に合わせた言葉（英語・日本語）
  const msg = (key, fallback) => { try { return chrome.i18n.getMessage(key) || fallback; } catch { return fallback; } };

  function getState() {
    const now = nowPlaying();
    const upNext = msg('upNext', 'Up next');
    if (!now) return { ok: true, now: null, mode: 'related', listTitle: upNext, items: [] };
    if (params().get('list')) {
      const p = playlistPanel();
      if (p) {
        return { ok: true, now, mode: 'playlist', listTitle: playlistTitle(p) || msg('playlist', 'Playlist'), items: playlistItems(p) };
      }
    }
    return { ok: true, now, mode: 'related', listTitle: upNext, items: relatedItems(now.id) };
  }

  // ---- 操作 ----
  function go(anchor, id) {
    if (anchor) anchor.click();             // YouTube内の移動（速い）
    else location.assign('/watch?v=' + id); // 予備：普通にページを開く
  }

  function playItem({ mode, index, id }) {
    if (mode === 'playlist') {
      const p = playlistPanel();
      const rows = p ? playlistRows(p) : [];
      const r = (rows[index] && rowId(rows[index]) === id) ? rows[index] : rows.find((x) => rowId(x) === id);
      return go(r && rowAnchor(r), id);
    }
    const a = $$('a[href*="/watch?v="]', relatedRoot()).find((x) => videoIdOf(x.getAttribute('href')) === id);
    go(a, id);
  }

  function togglePlay() {
    const v = video();
    if (!v) return;
    if (v.paused) v.play().catch(() => {}); else v.pause();
  }

  function next() {
    const btn = $('.ytp-next-button');
    if (btn && btn.getAttribute('aria-disabled') !== 'true' && btn.offsetParent !== null) return btn.click();
    const s = getState();
    if (s.mode === 'playlist') {
      const i = s.items.findIndex((x) => x.selected);
      const n = s.items[i + 1];
      if (n) playItem({ mode: 'playlist', index: n.index, id: n.id });
    } else if (s.items[0]) {
      playItem({ mode: 'related', index: 0, id: s.items[0].id });
    }
  }

  function prev() {
    const v = video();
    if (v && v.currentTime > 3) { v.currentTime = 0; return; } // 曲の途中なら頭に戻す
    const s = getState();
    if (s.mode === 'playlist') {
      const i = s.items.findIndex((x) => x.selected);
      const p = s.items[i - 1];
      if (p) return playItem({ mode: 'playlist', index: p.index, id: p.id });
    }
    history.back();
  }

  function seek(ratio) {
    const v = video();
    if (v && isFinite(v.duration)) v.currentTime = Math.max(0, Math.min(1, ratio)) * v.duration;
  }

  function handle(msg) {
    switch (msg.type) {
      case 'getState': return getState();
      case 'toggle': togglePlay(); break;
      case 'next': next(); break;
      case 'prev': prev(); break;
      case 'seek': seek(msg.ratio); break;
      case 'play': playItem(msg); break;
      default: return { ok: false, reason: 'unknown' };
    }
    return { ok: true };
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.target !== 'yt') return;
    try {
      sendResponse(handle(msg));
    } catch (e) {
      sendResponse({ ok: false, reason: 'error', error: String(e) });
    }
  });
})();
