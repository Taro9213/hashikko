// AI（Claude など）に部品を作ってもらうための依頼文（英語）。
// 部品の決まり（HTML 1つ、説明書、使える機能、見た目）をすべてここに書いてあるので、AI はこの文章だけで部品を作れる。
window.makerPrompt = (want, problem, current) => `You build "parts" (small tools) for a desktop app called Hashikko (Windows and Mac).
Hashikko is a small panel (about 300 px wide and 500 px tall) that slides out from the right edge of the screen and shows one part at a time.
People keep their current work on screen, pull the panel out from the edge, and finish a small task right there.
The person asking is not a programmer. Keep any words you write to them short and plain.
${current ? `
# The part to change
Here is the current code of a part the person already uses. Change it as described below, keep the same "id" in the manifest, and output the whole part again.
\`\`\`html
${current}
\`\`\`

# What should change
${want}
` : `
# The part to build
${want}
`}${problem ? `
# What went wrong last time
The part you made last time could not be added, for this reason. Fix it and output the whole part again.
${problem}
` : ''}
# Rules (must follow)
1. Output exactly one HTML file, inside one code block. Right after the code block, write this one line and nothing else:
   Next: click "Copy" on the code above, go back to Hashikko (open it from the right edge of your screen) and click "Load copied code".
2. Put all CSS and JavaScript inside that HTML file. External files, images, fonts, libraries and network requests are not available (they are all blocked). For pictures, use emoji or inline SVG.
   A part cannot connect to the internet, to accounts, or to other apps (calendars, email, Teams, Google, Spotify, files on the computer). If the request needs any of that, never pretend it works: build the closest version that works fully on its own (for example, a schedule the person types in), and before the code block write one short sentence saying what it cannot do and what it does instead.
3. Always include these three elements inside <head>:
   <link rel="stylesheet" href="https://app.hashikko/base.css">
   <script src="https://app.hashikko/sdk.js"></script>
   <script type="application/json" id="hashikko-manifest">(the manifest below)</script>
4. Do not use alert / confirm / prompt, localStorage, fetch, <form> submission, links to other sites, or new windows.
5. All text in the part is in English. It must be usable the moment it opens, without instructions. It must not send the user to another app or website.

# Manifest
Write JSON in this shape:
{
  "id": "a short name using only lowercase letters, digits and hyphens",
  "name": "the part's name (short)",
  "description": "what it does, in one line",
  "emoji": "one emoji that represents the part",
  "version": "1.0.0",
  "keyboard": true if the part has a text field, otherwise false,
  "permissions": only the ones you actually use, from ["storage", "clipboard.write"]
}

# Look and feel
- base.css provides colors and basic styles. Always use these variables for color (they adapt to light and dark mode):
  var(--bg) background / var(--surface) cards and inputs / var(--text) text / var(--muted) secondary text /
  var(--line) borders / var(--hover) hover background / var(--accent) accent color / var(--accent-soft) light accent background / var(--track) tracks and bars
- body has no margin and does not scroll. Give the outer wrapper padding: 16px and height: 100%, and make only the long parts overflow-y: auto.
- Text around 13px. Make the important numbers big. Buttons easy to click (at least 34px tall) with rounded corners (8–14px).
- Text selection is turned off. Add user-select: text to inputs and to text people should be able to copy.
- Put the most-used action at the top, and make it the biggest.

# Available functions (window.hashikko)
- await hashikko.call('storage.get', { key: 'data' })
    → { ok: true, value: the saved value (null if none) }. Needs "storage" in permissions. The key may use only lowercase letters, digits and hyphens.
- await hashikko.call('storage.set', { key: 'data', value: any JSON value })
- await hashikko.call('clipboard.write', { text: 'text to copy' }). Needs "clipboard.write" in permissions.
- hashikko.onVisible(function (visible) { ... })
    Called with true when the panel opens and false when it closes. Always call it at least once.
- The part keeps running when the panel is closed (timers keep going).
- Save content and settings that should persist with storage, and load them on start.

# Example (a counter part)
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://app.hashikko/base.css">
<script src="https://app.hashikko/sdk.js"></script>
<script type="application/json" id="hashikko-manifest">
{"id":"counter","name":"Counter","description":"Counts how many times you press","emoji":"🔢","version":"1.0.0","keyboard":false,"permissions":["storage"]}
</script>
<style>
.wrap { height: 100%; padding: 16px; display: flex; flex-direction: column; align-items: center; gap: 16px; }
.num { font-size: 64px; font-weight: 700; margin-top: 40px; font-variant-numeric: tabular-nums; }
.add { width: 100%; padding: 18px; border-radius: 14px; background: var(--accent); color: #fff; font-size: 18px; font-weight: 700; }
.reset { color: var(--muted); padding: 8px 14px; border-radius: 8px; }
.reset:hover { background: var(--hover); }
</style>
</head>
<body>
<div class="wrap">
  <div class="num" id="num">0</div>
  <button class="add" id="add">+1</button>
  <button class="reset" id="reset">Reset</button>
</div>
<script>
let n = 0;
const show = () => { document.getElementById('num').textContent = n; };
const save = () => hashikko.call('storage.set', { key: 'count', value: n });
document.getElementById('add').addEventListener('click', () => { n++; show(); save(); });
document.getElementById('reset').addEventListener('click', () => { n = 0; show(); save(); });
hashikko.call('storage.get', { key: 'count' }).then((r) => { if (r && typeof r.value === 'number') n = r.value; show(); });
hashikko.onVisible(() => {});
</script>
</body>
</html>

Now output ${current ? 'the changed part' : '"The part to build"'} as a single HTML file that follows the rules above.`;
