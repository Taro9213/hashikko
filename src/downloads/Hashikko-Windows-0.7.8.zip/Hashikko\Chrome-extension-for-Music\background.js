// Hashikko Player — 裏方。パネルからの依頼を、音楽を流しているYouTubeタブへ中継する。

async function findYouTubeTab() {
  const tabs = await chrome.tabs.query({ url: ['https://www.youtube.com/watch*'] });
  if (!tabs.length) return null;
  // 音が出ているタブを最優先、次に最後に触ったタブ
  tabs.sort((a, b) =>
    (b.audible ? 1 : 0) - (a.audible ? 1 : 0) ||
    (b.lastAccessed || 0) - (a.lastAccessed || 0));
  return tabs[0];
}

async function sendToYouTube(msg) {
  const tab = await findYouTubeTab();
  if (!tab) return { ok: false, reason: 'no-tab' };
  const payload = { ...msg, target: 'yt' };
  try {
    return await chrome.tabs.sendMessage(tab.id, payload);
  } catch (e) {
    // 拡張を入れる前から開いていたタブには、ここで受け手を差し込む
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['youtube.js'] });
    return await chrome.tabs.sendMessage(tab.id, payload);
  }
}

async function handle(msg) {
  if (msg.type === 'focusTab') {
    const tab = await findYouTubeTab();
    if (!tab) return { ok: false, reason: 'no-tab' };
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
    return { ok: true };
  }
  return sendToYouTube(msg);
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'bg') return;
  if (msg.type === 'appConnected') { sendResponse({ connected: appConnected() }); return; }
  handle(msg).then(sendResponse, (e) => sendResponse({ ok: false, reason: 'error', error: String(e) }));
  return true; // 非同期で返事をする
});

// ---------- Windowsアプリ（Hashikko Player）とのつながり ----------
// アプリが起動していれば、PCの中だけの通信でつなぎ、アプリからの依頼をYouTubeタブへ中継する。
const APP_URL = 'ws://127.0.0.1:47231';
let appSocket = null;
let reconnectTimer = null;

function appConnected() {
  return !!appSocket && appSocket.readyState === WebSocket.OPEN;
}

function connectApp() {
  if (appSocket && (appSocket.readyState === WebSocket.OPEN || appSocket.readyState === WebSocket.CONNECTING)) return;
  clearTimeout(reconnectTimer);
  let ws;
  try { ws = new WebSocket(APP_URL); } catch { return; }
  appSocket = ws;
  ws.onmessage = async (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }
    if (msg.type === 'ping') { ws.send(JSON.stringify({ type: 'pong' })); return; }
    // 新しい形：{ rid: 依頼番号, type, args: { 曲のid など } }。
    // 古い形（依頼番号と曲のidが同じ id に入って上書きされていた）にも念のため対応する。
    const isEnvelope = msg.rid !== undefined;
    const request = isEnvelope ? { ...(msg.args || {}), type: msg.type } : msg;
    let result;
    try { result = await handle(request); } catch (e) { result = { ok: false, reason: 'error', error: String(e) }; }
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(isEnvelope ? { rid: msg.rid, result } : { id: msg.id, result }));
    }
  };
  ws.onclose = () => {
    if (appSocket === ws) appSocket = null;
    reconnectTimer = setTimeout(connectApp, 3000);
  };
  ws.onerror = () => {}; // アプリが起動していないだけなので何もしない
}

// 拡張機能の裏方は、しばらく暇だとChromeに眠らされる。30秒ごとに起こしてつなぎ直す。
chrome.alarms.create('hashikko-connect', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'hashikko-connect') connectApp(); });
chrome.runtime.onStartup.addListener(connectApp);
connectApp();

// ブラウザーの中の端のパネル（edge.js）は、開発用の版だけにある。Chrome ウェブストアの版は YouTube とアプリをつなぐだけ
const HAS_EDGE = (chrome.runtime.getManifest().content_scripts || []).some((c) => (c.js || []).includes('edge.js'));

// キーボードショートカット（Alt+Shift+Y）。アプリが動いているときはアプリ側が受け持つ。
if (HAS_EDGE) chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'toggle-panel' || appConnected()) return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) chrome.tabs.sendMessage(tab.id, { target: 'edge', type: 'toggle' }).catch(() => {});
});

// インストール直後でも、すでに開いているタブですぐ使えるようにする
chrome.runtime.onInstalled.addListener(async () => {
  const tabs = await chrome.tabs.query({ url: HAS_EDGE ? ['http://*/*', 'https://*/*'] : ['https://www.youtube.com/*'] });
  for (const t of tabs) {
    if (HAS_EDGE) chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['edge.js'] }).catch(() => {});
    if (/^https:\/\/www\.youtube\.com\//.test(t.url || '')) {
      chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['youtube.js'] }).catch(() => {});
    }
  }
});
