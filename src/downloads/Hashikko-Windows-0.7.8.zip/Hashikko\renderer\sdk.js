// 部品のための窓口。部品からは window.hashikko として見える。
// 部品は本体（シェル）に頼みごとを送り、シェルがアプリ本体（C#）に取り次ぐ。
// 使える命令は、説明書（manifest.json）の permissions に書いたものだけ。
(() => {
  const pending = new Map();
  let seq = 0;
  let onVisible = null;
  const send = (m) => window.parent.postMessage(m, '*');

  window.addEventListener('message', (e) => {
    if (e.source !== window.parent) return;
    const m = e.data || {};
    if (m.hk === 'result') {
      const resolve = pending.get(m.id);
      if (resolve) { pending.delete(m.id); resolve(m.result); }
    } else if (m.hk === 'visible' && onVisible) {
      onVisible(!!m.value);
    } else if (m.hk === 'ping') {
      // 本体からの「動いている？」に答える。答えられないほど重くなった部品は、本体が止める
      send({ hk: 'pong', n: m.n });
    }
  });

  window.hashikko = {
    // 本体に頼みごとをする。例: hashikko.call('storage.get', { key: 'notes' })
    call: (type, extra) => new Promise((resolve) => {
      const id = ++seq;
      pending.set(id, resolve);
      send({ hk: 'call', id, type, extra: extra || {} });
    }),
    // パネルを閉じる
    close: () => send({ hk: 'close' }),
    // この部品が「見えた / 隠れた」ときに呼ばれる
    onVisible: (cb) => { onVisible = cb; send({ hk: 'ready' }); },
    // 文字を打てるようにする（説明書に "keyboard": true がある部品だけ）
    focus: () => send({ hk: 'focus' }),
  };

  // 入力欄を押したら、文字を打てるようにする
  document.addEventListener('pointerdown', (e) => {
    const t = e.target;
    if (t && t.closest && t.closest('textarea, input, [contenteditable]')) send({ hk: 'focus' });
  }, true);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') send({ hk: 'close' }); });
})();
