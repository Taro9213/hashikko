# Builds the zip for the Chrome Web Store (only links YouTube and the Hashikko app; needs access to YouTube only).
#   powershell -ExecutionPolicy Bypass -File make-store-zip.ps1   -> dist\hashikko-player-store-<version>.zip
# The development version (this folder itself, with the in-browser edge panel) is not changed.
# Entry names use "/" (Windows PowerShell's Compress-Archive writes "\", which the store may not accept).
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$manifest = Get-Content (Join-Path $here 'store\manifest.json') -Raw | ConvertFrom-Json
$ver = $manifest.version
$files = [ordered]@{
  'manifest.json' = Join-Path $here 'store\manifest.json'
  'background.js' = Join-Path $here 'background.js'
  'youtube.js'    = Join-Path $here 'youtube.js'
}
foreach ($f in Get-ChildItem (Join-Path $here 'icons') -Filter *.png) { $files["icons/$($f.Name)"] = $f.FullName }
New-Item -ItemType Directory (Join-Path $here 'dist') -Force | Out-Null
$zip = Join-Path $here "dist\hashikko-player-store-$ver.zip"
if (Test-Path $zip) { Remove-Item $zip -Force }
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
$archive = [IO.Compression.ZipFile]::Open($zip, 'Create')
try {
  foreach ($name in $files.Keys) { [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $files[$name], $name) }
} finally { $archive.Dispose() }
"Done: $zip"
