// 画面全体に大きく出す案内。アプリ本体（Windows: C# / Mac: Swift）から { kind:'show', mode, data, backdrop } が届く。
// ボタンが押されたら { kind: 'coach-go' など, data } を本体に返す。
const el = (id) => document.getElementById(id);
const MODES = ['coach-paste', 'coach-wait', 'coach-found', 'tidy'];
let mode = '';
let data = {};

function send(kind, d) {
  const msg = { kind, data: d || {} };
  if (window.chrome && window.chrome.webview) window.chrome.webview.postMessage(msg);
  else if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.overlay) window.webkit.messageHandlers.overlay.postMessage(msg);
}

function receive(m) {
  if (!m) return;
  if (m.kind === 'hide') { mode = ''; for (const x of MODES) el(x).hidden = true; return; }
  if (m.kind !== 'show') return;
  mode = m.mode;
  data = m.data || {};
  if (m.backdrop) { el('bg').style.backgroundImage = `url("${m.backdrop}")`; document.body.className = ''; }
  else if (m.backdrop === null) document.body.className = 'solid';
  if (data.mac) document.body.className = 'clear';   // Mac は窓そのものが透ける
  for (const x of MODES) el(x).hidden = x !== mode;
  if (mode === 'coach-paste') renderPaste();
  if (mode === 'coach-found') renderFound();
  if (mode === 'tidy') renderTidy();
  const first = document.querySelector(`#${mode} .primary`);
  if (first) setTimeout(() => first.focus(), 30);
}
if (window.chrome && window.chrome.webview) window.chrome.webview.addEventListener('message', (e) => receive(e.data));
window.hashikkoOverlay = receive;   // Mac：本体が evaluateJavaScript で呼ぶ

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (mode === 'coach-paste') send('coach-cancel');
    else if (mode === 'coach-found') send('coach-cancel');
    else if (mode === 'tidy') send('tidy-cancel');
  } else if (e.key === 'Enter' && !(e.target && e.target.closest && e.target.closest('button'))) {
    const p = document.querySelector(`#${mode} .primary:not([hidden])`);
    if (p && p.offsetParent) p.click();
  }
});

// ---- 部品づくり ----
function renderPaste() {
  el('kPaste').textContent = data.paste || 'Ctrl + V';
  el('kEnter').textContent = data.enter || 'Enter';
  el('cpLead').textContent = data.browser
    ? `Claude is opening in ${data.browser}. Do this there:`
    : 'Open Claude (or another AI) and do this:';
  el('cpGo').textContent = data.browser ? 'Got it, take me to Claude' : 'Got it';
}
el('cpGo').addEventListener('click', () => send('coach-go'));
el('cpCancel').addEventListener('click', () => send('coach-cancel'));
el('cwSteps').addEventListener('click', () => send('coach-steps'));
el('cwStop').addEventListener('click', () => send('coach-cancel'));

const REASONS = {
  'no-html': "What you copied isn't the whole code. Copy the code again with the Copy button.",
  'no-manifest': 'The code is missing the part details Hashikko needs.',
  'bad-manifest': 'The part details in the code are not written correctly.',
  'no-name': 'The part has no name.',
  'too-big': 'The part is too large (400 KB max).',
};
const text = (v) => (v && typeof v === 'object' ? (v.en || v.ja || '') : (v || ''));
function renderFound() {
  el('cfOk').hidden = !data.ok;
  el('cfBad').hidden = !!data.ok;
  if (!data.ok) { el('cfReason').textContent = (REASONS[data.reason] || "Hashikko couldn't read it as a part.") + ' Hashikko can copy a request to fix it.'; return; }
  el('cfEmoji').textContent = data.emoji || '🧩';
  el('cfName').textContent = text(data.name);
  el('cfDesc').textContent = text(data.description);
  el('cfNote').textContent = "It works offline and can't connect to the internet."
    + (data.exists ? ' It replaces the version you have now.' : '');
}
el('cfAdd').addEventListener('click', () => send('coach-add'));
el('cfLater').addEventListener('click', () => send('coach-cancel'));
el('cfFix').addEventListener('click', () => send('coach-open'));
el('cfClose').addEventListener('click', () => send('coach-cancel'));

// ---- お片付け：残すアプリを選ぶ ----
let keep = new Set();
const key = (a) => String(a || '').toLowerCase();

function renderTidy() {
  const saved = new Set((data.keepApps || []).map(key));
  const stays = (a) => a.meeting || a.current || saved.has(key(a.app));
  // 残るアプリを先頭に並べる（下に隠れて気づけない、をなくす）。並びは開いている間は変えない
  const apps = [...(data.apps || [])].sort((a, b) => Number(stays(b)) - Number(stays(a)));
  keep = new Set(apps.filter(stays).map((a) => key(a.app)));
  el('tdLead').textContent = data.mac
    ? 'Click the apps people may see while you share. Everything else is hidden until you click Restore.'
    : 'Click the apps people may see while you share. Everything else is minimized until you click Restore.';
  const grid = el('tdGrid');
  if (!apps.length) {
    const e = document.createElement('p'); e.className = 'empty';
    e.textContent = 'No other apps are open. Tidy up will just cover your desktop.';
    grid.replaceChildren(e);
  } else {
    grid.replaceChildren(...apps.map(card));
  }
  renderSum();
  requestAnimationFrame(fitGrid);
}

// 全部のアプリが、スクロールせずに1画面に収まるように、カードを小さくしていく
function fitGrid() {
  const grid = el('tdGrid');
  grid.classList.remove('dense', 'denser', 'more');
  for (const c of ['dense', 'denser']) {
    if (grid.scrollHeight <= grid.clientHeight + 2) return;
    grid.classList.add(c);
  }
  // それでも入りきらないとき（アプリがとても多い）は、下にまだあることをはっきり見せる
  grid.classList.toggle('more', grid.scrollHeight > grid.clientHeight + 2);
}
window.addEventListener('resize', () => { if (!el('tidy').hidden) fitGrid(); });

function card(a) {
  const k = key(a.app);
  const b = document.createElement('button');
  b.className = 'app' + (a.meeting ? ' locked' : '');
  b.dataset.k = k;
  const shot = document.createElement('div'); shot.className = 'shot';
  if (a.thumb) shot.style.backgroundImage = `url("${a.thumb}")`;
  else if (a.icon) { const i = document.createElement('img'); i.className = 'big'; i.src = a.icon; i.alt = ''; shot.append(i); }
  else { const l = document.createElement('div'); l.className = 'letter'; l.textContent = (a.name || '?').slice(0, 1).toUpperCase(); shot.append(l); }
  const row = document.createElement('div'); row.className = 'row';
  if (a.icon && a.thumb) { const i = document.createElement('img'); i.src = a.icon; i.alt = ''; row.append(i); }
  const n = document.createElement('span'); n.className = 'name'; n.textContent = a.name || a.app; row.append(n);
  const t = document.createElement('div'); t.className = 'title';
  t.textContent = a.title && a.title !== a.name ? a.title : (a.windows > 1 ? `${a.windows} windows` : '');
  if (a.windows > 1 && a.title && a.title !== a.name) t.textContent += ` (+${a.windows - 1} more)`;
  const tag = document.createElement('span'); tag.className = 'tag';
  const chk = document.createElement('span'); chk.className = 'check'; chk.textContent = '✓';
  b.append(shot, row, t, tag, chk);
  b.title = a.meeting ? 'Meeting apps always stay on screen' : 'Click to switch';
  b.addEventListener('click', () => {
    if (a.meeting) return;
    if (keep.has(k)) keep.delete(k); else keep.add(k);
    renderSum();
  });
  b._app = a;
  return b;
}

function renderSum() {
  let stay = 0, go = 0;
  for (const b of el('tdGrid').querySelectorAll('.app')) {
    const a = b._app;
    const on = keep.has(b.dataset.k);
    b.classList.toggle('keep', on);
    b.setAttribute('aria-pressed', String(on));
    b.querySelector('.tag').textContent = a.meeting ? 'Meeting app · always stays'
      : on ? (a.current ? 'Stays · you were using it' : 'Stays on screen')
      : (data.mac ? 'Will be hidden' : 'Will be minimized');
    if (on) stay++; else go++;
  }
  const verb = data.mac ? 'hidden' : 'minimized';
  // 残るアプリの名前を下にも並べる（どれが残るか、一目でわかるように）
  const names = [...el('tdGrid').querySelectorAll('.app.keep')].map((b) => b._app.name || b._app.app);
  el('tdSum').replaceChildren();
  const s1 = document.createElement('b'); s1.textContent = stay ? `Stays on screen: ${names.join(', ')}` : 'Nothing stays on screen';
  const s2 = document.createElement('b'); s2.textContent = `${go} will be ${verb}`;
  el('tdSum').append(s1, ' · ', s2);
}

el('tdGo').addEventListener('click', () => {
  const cur = (data.apps || []).find((a) => a.current);
  send('tidy-go', { keepApps: [...keep], current: cur ? key(cur.app) : '' });
});
el('tdCancel').addEventListener('click', () => send('tidy-cancel'));

send('ready');
