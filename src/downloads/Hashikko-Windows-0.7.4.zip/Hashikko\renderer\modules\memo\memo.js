// メモの部品 — 文字だけの短いメモ。書いたらすぐ自動で保存する。データはこのPCの中だけ。
const api = window.hashikko;
const el = (id) => document.getElementById(id);
const ui = {
  list: el('list'), text: el('text'), status: el('status'), newBtn: el('new'), copy: el('copy'), del: el('del'),
  trashToggle: el('trashToggle'), toast: el('toast'), toastText: el('toastText'), undo: el('undo'), editor: el('editor'),
};

const KEEP_DAYS = 7;             // 削除したメモを残しておく日数
let notes = [];                  // { id, text, updated, deleted? }
let current = null;              // 開いているメモのid
let showTrash = false;
let loaded = false;
let saveTimer = null;
let toastTimer = null;
let lastDeleted = null;
let visible = false;

const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const live = () => notes.filter((n) => !n.deleted).sort((a, b) => b.updated - a.updated);
const trash = () => notes.filter((n) => n.deleted).sort((a, b) => b.deleted - a.deleted);
const titleOf = (n) => (n.text.split('\n').find((l) => l.trim()) || '').trim();

function fmtDate(t) {
  const d = new Date(t), now = new Date();
  const pad = (x) => String(x).padStart(2, '0');
  if (d.toDateString() === now.toDateString()) return d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  return `${d.getMonth() + 1}/${d.getDate()}`;
}

// ---- 保存 ----
async function load() {
  const r = await api.call('storage.get', { key: 'notes' });
  const v = (r && r.value) || {};
  notes = Array.isArray(v.notes) ? v.notes : [];
  const limit = Date.now() - KEEP_DAYS * 86400000;
  notes = notes.filter((n) => !n.deleted || n.deleted > limit);   // 古いごみ箱の中身を片付ける
  current = notes.some((n) => n.id === v.current && !n.deleted) ? v.current : (live()[0] || {}).id || null;
  loaded = true;
  render();
  if (visible) focusText();
}

async function saveNow() {
  clearTimeout(saveTimer); saveTimer = null;
  if (!loaded) return;
  const r = await api.call('storage.set', { key: 'notes', value: { notes, current } });
  ui.status.textContent = r && r.ok ? 'Saved' : "Couldn't save";
}
function saveSoon() {
  ui.status.textContent = '';
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNow, 400);
}

// ---- 描画 ----
function renderList() {
  const items = showTrash ? trash() : live();
  const frag = document.createDocumentFragment();
  for (const n of items) {
    const li = document.createElement('li');
    const b = document.createElement(showTrash ? 'div' : 'button');
    b.className = 'item' + (!showTrash && n.id === current ? ' selected' : '');
    const t = document.createElement('span');
    const title = titleOf(n);
    t.className = 'ititle' + (title ? '' : ' blank');
    t.textContent = title || '(empty note)';
    const d = document.createElement('span');
    d.className = 'idate';
    d.textContent = fmtDate(showTrash ? n.deleted : n.updated);
    b.append(t, d);
    if (showTrash) {
      const r = document.createElement('button');
      r.className = 'restore';
      r.textContent = 'Restore';
      r.addEventListener('click', () => { restore(n.id); });
      // 完全に消す：1回目で「Delete forever?」に変わり、もう一度押すと消える（3秒で元に戻る）
      const x = document.createElement('button');
      x.className = 'forever';
      x.textContent = 'Delete';
      x.title = 'Delete this note for good';
      x.addEventListener('click', () => {
        if (!x.classList.contains('armed')) {
          x.classList.add('armed'); x.textContent = 'Delete forever?';
          setTimeout(() => { if (x.isConnected) { x.classList.remove('armed'); x.textContent = 'Delete'; } }, 3000);
          return;
        }
        notes = notes.filter((m) => m.id !== n.id);
        if (!trash().length) showTrash = false;
        render(); saveNow();
      });
      b.append(r, x);
    } else {
      b.addEventListener('click', () => { open(n.id); });
    }
    li.append(b);
    frag.append(li);
  }
  if (!items.length) {
    const li = document.createElement('li');
    li.className = 'listempty';
    li.textContent = showTrash ? 'No recently deleted notes.' : 'Start typing below to create a note.';
    frag.append(li);
  } else if (showTrash) {
    const li = document.createElement('li');
    li.className = 'listempty';
    li.textContent = `Deleted notes go away by themselves after ${KEEP_DAYS} days.`;
    frag.append(li);
  }
  ui.list.replaceChildren(frag);
  const tc = trash().length;
  ui.trashToggle.hidden = !tc && !showTrash;
  ui.trashToggle.textContent = showTrash ? '← Back to notes' : `Recently deleted (${tc})`;
  const empty = el('emptyTrash');
  empty.hidden = !showTrash || !tc;
  if (empty.hidden) { empty.classList.remove('armed'); empty.textContent = 'Delete all'; }
}

function render() {
  renderList();
  const n = notes.find((x) => x.id === current && !x.deleted);
  ui.editor.hidden = showTrash;
  if (ui.text.dataset.id !== (current || '')) {
    ui.text.value = n ? n.text : '';
    ui.text.dataset.id = current || '';
  }
  ui.copy.disabled = ui.del.disabled = !n;
}

// ---- 操作 ----
function open(id) {
  current = id;
  showTrash = false;
  render();
  saveSoon();
  focusText();
}

function focusText() {
  ui.text.focus();
  ui.text.setSelectionRange(ui.text.value.length, ui.text.value.length);
  api.focus();
}

ui.newBtn.addEventListener('click', () => {
  // 何も書いていないメモがあれば、それを使う（空のメモを増やさない）
  const blank = live().find((n) => !n.text.trim());
  if (blank) { blank.updated = Date.now(); open(blank.id); return; }
  const n = { id: newId(), text: '', updated: Date.now() };
  notes.push(n);
  open(n.id);
});

ui.text.addEventListener('input', () => {
  let n = notes.find((x) => x.id === current && !x.deleted);
  if (!n) {
    n = { id: newId(), text: '', updated: Date.now() };
    notes.push(n);
    current = n.id;
    ui.text.dataset.id = n.id;
  }
  n.text = ui.text.value;
  n.updated = Date.now();
  ui.copy.disabled = ui.del.disabled = false;
  renderList();
  saveSoon();
});
ui.text.addEventListener('blur', () => { if (saveTimer) saveNow(); });

ui.copy.addEventListener('click', async () => {
  const n = notes.find((x) => x.id === current);
  if (!n || !n.text) return;
  const r = await api.call('clipboard.write', { text: n.text });
  ui.status.textContent = r && r.ok ? 'Copied' : "Couldn't copy";
});

ui.del.addEventListener('click', () => {
  const n = notes.find((x) => x.id === current);
  if (!n) return;
  if (!n.text.trim()) notes = notes.filter((x) => x !== n);   // 空のメモは、ごみ箱に入れずに消す
  else {
    n.deleted = Date.now();
    lastDeleted = n.id;
    ui.toastText.textContent = 'Note deleted';
    ui.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { ui.toast.hidden = true; }, 6000);
  }
  current = (live()[0] || {}).id || null;
  render();
  saveNow();
});

function restore(id) {
  const n = notes.find((x) => x.id === id);
  if (!n) return;
  delete n.deleted;
  n.updated = Date.now();
  ui.toast.hidden = true;
  open(id);
  saveNow();
}
ui.undo.addEventListener('click', () => { if (lastDeleted) restore(lastDeleted); });

ui.trashToggle.addEventListener('click', () => { showTrash = !showTrash; render(); });

// ごみ箱を空にする：1回目で「Delete all N for good?」に変わり、もう一度押すと全部消える
el('emptyTrash').addEventListener('click', () => {
  const b = el('emptyTrash');
  if (!b.classList.contains('armed')) {
    b.classList.add('armed'); b.textContent = `Delete all ${trash().length} for good?`;
    setTimeout(() => { if (b.classList.contains('armed')) { b.classList.remove('armed'); b.textContent = 'Delete all'; } }, 3000);
    return;
  }
  notes = notes.filter((n) => !n.deleted);
  showTrash = false;
  render(); saveNow();
});

// 見えたらすぐ書けるようにする。隠れるときは、書きかけを必ず保存する
api.onVisible((v) => {
  visible = v;
  if (v) { if (loaded && !showTrash) focusText(); }
  else if (saveTimer) saveNow();
});

load();
