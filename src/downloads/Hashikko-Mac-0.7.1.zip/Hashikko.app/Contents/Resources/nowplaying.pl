# Hashikko：/usr/bin/perl に nowplaying.dylib を読み込ませて、再生中の情報を読む・操作する。
# 使い方: /usr/bin/perl nowplaying.pl <nowplaying.dylib のパス>
use DynaLoader;
my $lib = DynaLoader::dl_load_file($ARGV[0], 0) or die DynaLoader::dl_error();
my $sym = DynaLoader::dl_find_symbol($lib, "hk_main") or die DynaLoader::dl_error();
DynaLoader::dl_install_xsub("main::hk_main", $sym);
hk_main();
